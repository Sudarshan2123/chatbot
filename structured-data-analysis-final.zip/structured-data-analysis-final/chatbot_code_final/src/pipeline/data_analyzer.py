import logging
# import time  <- Removed, no longer needed
from typing import Dict, List, Optional # <- Removed Generator
import pandas as pd
from langchain_google_vertexai import ChatVertexAI
# from langchain.agents import AgentType
# from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit


from src.pipeline.core import (
    AnalysisContext, AnalysisResult, AnalysisType, AnalysisDecision,
    TableMetadata, RoutingDecision, AnalysisConfig, PandasOptionsManager,
    ResponseCleaner, DataAnalysisError, LLMTimeoutError
)
from src.pipeline.response_naturalizer import ResponseNaturalizer
from src.pipeline.table_router import TableRouter

logger = logging.getLogger(__name__)


class DataAnalyzer:
    """
    Main data analyzer class with proper separation of concerns.
    Orchestrates routing and analysis operations.
    """
    
    def __init__(self, config, db_manager, enable_naturalization=True):
        """Initialize with optional response naturalization"""
        try:
            from config.Authentication.gcp import load_gcp_credentials
            
            self.config = config
            self.db_manager = db_manager
            credentials = load_gcp_credentials()
            
            # Initialize LLM
            self.llm = ChatVertexAI(
                model_name=self.config.RAG_MODEL,
                temperature=0.0,
                max_output_tokens=4096,
                credentials=credentials
            )
            
            # Initialize components
            self.router = TableRouter(self.llm)

            # 🔧 NEW: Initialize Database Toolkit
            sql_engine = db_manager.get_sqlalchemy_engine()
            db = SQLDatabase(
                engine=sql_engine,
                schema=db_manager.schema,
                include_tables=None  # Allow dynamic table discovery
            )
            
            self.toolkit = SQLDatabaseToolkit(db=db, llm=self.llm)
            self.tools = self.toolkit.get_tools()
            
            logger.info(f"Initialized {len(self.tools)} database interaction tools")
            
            # NEW: Initialize naturalizer
            self.enable_naturalization = enable_naturalization
            if enable_naturalization:
                self.naturalizer = ResponseNaturalizer(self.llm)
                logger.info("Response naturalization enabled")
            else:
                self.naturalizer = None
            
            logger.info("DataAnalyzer (SQL Mode) initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize DataAnalyzer: {e}")
            raise
    
    def detect_table_intent(self, state: dict) -> dict:
        """
        Detect which tables are relevant for the user's query.
        
        Args:
            state: Agent state with user input and available tables
            
        Returns:
            Updated state with routing decision
        """
        user_input = state.get("input", "")
        available_tables = state.get("available_tables", {})
        
        if not available_tables:
            logger.error("No tables available for routing")
            return {
                **state,
                "decision": AnalysisDecision.ERROR_NO_TABLES.value,
                "response": "No database tables are currently loaded."
            }
        
        try:
            # Convert metadata format
            table_metadata = {
                name: TableMetadata(
                    name=name,
                    columns=meta.get("columns", []),
                    data_types=meta.get("data_types", []),
                    row_count=meta.get("row_count", 0)
                )
                for name, meta in available_tables.items()
            }
            
            # Route tables
            routing_decision = self.router.route_tables(user_input, table_metadata)
            
            logger.info(f"Routed to tables: {routing_decision.relevant_tables}")
            
            return {
                **state,
                "selected_tables": routing_decision.relevant_tables,
                "decision": AnalysisDecision.LOAD_SELECTED_TABLES.value,
                "analysis_context": {
                    "analysis_type": routing_decision.analysis_type.value,
                    "relationship_type": routing_decision.relationship_type.value,
                    "confidence": routing_decision.confidence.value,
                    "reasoning": routing_decision.reasoning,
                    "expected_insights": routing_decision.expected_insights
                }
            }
            
        except Exception as e:
            logger.error(f"Error in table routing: {e}", exc_info=True)
            return {
                **state,
                "selected_tables": [],
                "decision": AnalysisDecision.STOP_ANALYSIS.value,
                "analysis_context": f"Unable to determine relevant tables: {str(e)}"
            }
    def _create_lookup_aware_system_prompt(self, selected_tables: List[str]) -> str:
        """
        Create system prompt that enforces lookup table resolution.
        
        Args:
            selected_tables: List of tables selected by router
            
        Returns:
            Enhanced system prompt string
        """
        # Identify lookup/master tables
        lookup_tables = [t for t in selected_tables if 'master' in t.lower() or 'mst' in t.lower()]
        
        base_prompt = f"""You are an expert SQL analyst working with an Oracle database.

    **AVAILABLE TABLES**: {', '.join(selected_tables)}

    **CRITICAL RULES**:

    1. **ALWAYS USE ALL AVAILABLE TABLES**:
    - You have been provided with {len(selected_tables)} carefully selected tables
    - Do NOT ignore any table, especially lookup/master tables
    - ALL tables are relevant to answering the user's query

    2. **LOOKUP TABLE RESOLUTION** (MANDATORY):
    - The following are lookup/master tables: {', '.join(lookup_tables) if lookup_tables else 'None identified'}
    - **ALWAYS JOIN** with lookup tables to resolve IDs to human-readable names
    - NEVER return raw ID values (designation_id, department_id, status_id, etc.)
    - Example: If you see 'designation_id' in employee_master, JOIN with 'designation_master'

    3. **SCHEMA INSPECTION**:
    - Call sql_db_schema for ALL tables: {', '.join(selected_tables)}
    - Examine foreign key relationships and column name patterns
    - Look for columns ending in '_id' or '_code' - these require lookups

    4. **QUERY CONSTRUCTION**:
    - Build comprehensive JOINs that include ALL relevant tables
    - Use LEFT JOIN for optional lookups, INNER JOIN for required data
    - Example pattern:
    ```sql
        SELECT 
            emp.emp_name,
            dept.dept_name,        -- NOT dept_id
            desig.designation_name -- NOT designation_id
        FROM employee_master emp
        LEFT JOIN department_mst dept ON emp.department_id = dept.department_id
        LEFT JOIN designation_master desig ON emp.designation_id = desig.designation_id
    ```

    5. **VALIDATION**:
    - Before executing, verify you've joined ALL lookup tables
    - If returning any column with '_id' or '_code' suffix, you've made an error

    6. **ERROR HANDLING**:
    - Oracle syntax: Do NOT use 'AS' keyword for table aliases
    - Correct: `FROM employee_master emp`
    - Incorrect: `FROM employee_master AS emp`

    **YOUR TASK**: Answer the user's query using ALL {len(selected_tables)} tables provided, 
    resolving ALL ID fields to human-readable values."""

        return base_prompt
    
    def _extract_clean_response(self, response: any) -> str:
        """
        Robustly extract clean text from various LangChain response formats.
        
        Handles:
        1. Simple strings (LangChain 0.1.x on localhost)
        2. Dicts with 'output' key (standard agent format)
        3. Lists of message chunks (LangChain 0.2.x + Vertex AI on server)
        4. AIMessage objects with .content attribute
        
        Args:
            response: Raw response from SQL agent executor
            
        Returns:
            Clean text string ready for naturalization
        """
        try:
            # Case 1: Already a clean string
            if isinstance(response, str):
                logger.debug("Response is already a string")
                return response.strip()
            
            # Case 2: Dictionary with 'output' key (most common)
            if isinstance(response, dict):
                if 'output' in response:
                    output = response['output']
                    logger.debug(f"Extracted 'output' key (type: {type(output)})")
                    # Recursively handle nested structures
                    return self._extract_clean_response(output)
                
                # Fallback for dicts without 'output'
                logger.warning(f"Dict without 'output' key. Available keys: {list(response.keys())}")
                if 'result' in response:
                    return self._extract_clean_response(response['result'])
                
                # Last resort: stringify
                return str(response)
            
            # Case 3: List of message chunks (SERVER ISSUE - THIS IS THE FIX!)
            if isinstance(response, list):
                logger.debug(f"Response is a list with {len(response)} items")
                text_parts = []
                
                for idx, item in enumerate(response):
                    if isinstance(item, dict):
                        # Extract 'text' field from Vertex AI message chunks
                        if 'text' in item:
                            text_parts.append(item['text'])
                            logger.debug(f"Extracted 'text' from list item {idx}")
                        elif 'type' in item and item['type'] == 'text' and 'text' in item:
                            text_parts.append(item['text'])
                        # Ignore metadata fields like 'thought_signature'
                    elif isinstance(item, str):
                        text_parts.append(item)
                
                if text_parts:
                    clean_text = ' '.join(text_parts).strip()
                    logger.info(f"Successfully extracted text from list: '{clean_text[:100]}...'")
                    return clean_text
                
                # No extractable text found
                logger.error(f"List contains no extractable text. Sample: {response[:200]}")
                return str(response)
            
            # Case 4: LangChain message objects (AIMessage, etc.)
            if hasattr(response, 'content'):
                logger.debug("Response has .content attribute")
                content = response.content
                return self._extract_clean_response(content)  # Recursive
            
            # Case 5: Unknown format
            logger.warning(f"Unknown response type: {type(response)}")
            return str(response)
            
        except Exception as e:
            logger.error(f"Error in _extract_clean_response: {e}", exc_info=True)
            # Absolute fallback
            return str(response)
    
    # def analyze_data_with_routing(self, state: dict) -> str:
        selected_tables = state.get("selected_tables", [])
        user_input = state.get("input", "")
        
        # Get SQLAlchemy Engine
        sql_engine = self.db_manager.get_sqlalchemy_engine()
        
        # 🔒 SECURITY: Limit agent to pre-selected tables only
        db = SQLDatabase(
            engine=sql_engine,
            schema=self.db_manager.schema,
            include_tables=selected_tables  # ⚠️ Critical: Restrict scope
        )
        
        # Create agent with toolkit tools
        sql_agent_executor = create_sql_agent(
            llm=self.llm,
            db=db,
            agent_type="openai-tools",
            verbose=True,
            handle_parsing_errors=True,
            extra_tools=self.tools  # 🔧 Add toolkit capabilities
        )
        
        raw_response_dict = sql_agent_executor.invoke({"input": user_input})
        if self.enable_naturalization and self.naturalizer:
                try:
                    naturalized_response = self.naturalizer.naturalize_response(
                        raw_response_dict,
                        user_input
                    )
                    logger.info("Response naturalized successfully")
                    return naturalized_response
                except Exception as e:
                    logger.warning(f"Naturalization failed, returning raw response: {e}")
                    return raw_response_dict
            
        return raw_response_dict
    
    
        # except Exception as e:
        #     logger.error(f"Error in analysis: {e}", exc_info=True)
        #     return f"Analysis error: {str(e)}"
    
    def analyze_data_with_routing(self, state: dict) -> str:
        selected_tables = state.get("selected_tables", [])
        user_input = state.get("input", "")
        
        if not selected_tables:
            return "No tables selected for analysis."

        try:
            sql_engine = self.db_manager.get_sqlalchemy_engine()
            if sql_engine is None:
                return "Analysis error: Database engine is not available."
            
            db = SQLDatabase(
                engine=sql_engine,
                schema=self.db_manager.schema,
                include_tables=selected_tables
            )

             # 🔧 FIX: Create enhanced system prompt that enforces lookup table usage
            agent_system_prompt = self._create_lookup_aware_system_prompt(selected_tables)
            
            logger.info(f"Creating SQL agent for tables: {selected_tables}")
            sql_agent_executor = create_sql_agent(
                llm=self.llm,
                db=db,
                agent_type="openai-tools",
                verbose=True,
                handle_parsing_errors=True,
                prefix=agent_system_prompt
            )
            
            raw_response_dict = sql_agent_executor.invoke({"input": user_input})
            
            # ✅ FIX: ROBUST EXTRACTION using new helper method
            raw_response = self._extract_clean_response(raw_response_dict)
            
            logger.info(f"Extracted response (type: {type(raw_response)}): {raw_response[:100]}...")
            
            # # 🔧 FIX: Ensure we have a string before naturalization
            # if isinstance(raw_response_dict, dict):
            #     raw_response = raw_response_dict.get('output', '')
            #     if not raw_response:
            #         # Fallback: try to extract any string representation
            #         raw_response = str(raw_response_dict.get('result', raw_response_dict))
            # else:
            #     # Handle case where response is already a string
            #     raw_response = str(raw_response_dict)
            
            # # 🔧 FIX: Validate it's actually a string
            # if not isinstance(raw_response, str):
            #     logger.error(f"Expected string, got {type(raw_response)}: {raw_response}")
            #     raw_response = str(raw_response)
            
            # logger.info(f"Extracted response (type: {type(raw_response)}): {raw_response[:100]}...")
            
            if self.enable_naturalization and self.naturalizer:
                try:
                    naturalized_response = self.naturalizer.naturalize_response(
                        raw_response,
                        user_input
                    )
                    logger.info("Response naturalized successfully")
                    return naturalized_response
                except Exception as e:
                    logger.warning(f"Naturalization failed, returning raw response: {e}")
                    return raw_response
            
            return raw_response
            
        except Exception as e:
            logger.error(f"Error in analysis: {e}", exc_info=True)
            return f"Analysis error: {str(e)}"

    def analyze_data_stream(
        self,
        dfs: Dict[str, pd.DataFrame],
        query: str
    ) -> str: # <- Changed return type from Generator to str
        """
        Legacy method for backward compatibility.
        Creates state and calls routing-based analysis.
        Returns a single response string.
        """
        # This would need session state from Streamlit
        # Better to inject dependencies instead
        logger.warning("analyze_data_stream called - prefer routing-based method")
        
        # Create minimal state
        state = {
            "input": query,
            "session_id": "legacy",
            "available_tables": {
                name: {
                    "columns": list(df.columns),
                    "data_types": [str(dt) for dt in df.dtypes],
                    "row_count": len(df)
                }
                for name, df in dfs.items()
            },
            "loaded_data": dfs
        }
        
        # Route tables
        state = self.detect_table_intent(state)
        
        # Check if routing failed
        if state.get("decision") != AnalysisDecision.LOAD_SELECTED_TABLES.value:
            return state.get("response", "Error during table routing.")

        # Analyze
        final_state = self.analyze_data_with_routing(state)
        
        # Return the final response string
        return final_state.get("response", "Analysis completed with no output.")