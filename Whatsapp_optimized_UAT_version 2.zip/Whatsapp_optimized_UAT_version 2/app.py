import contextlib
import datetime
import json, uvicorn
import logging
from typing import Optional, Dict, Any
from fastapi import Depends, FastAPI, HTTPException, status, Request,Header
from fastapi.middleware.cors import CORSMiddleware
from src.config import REDIS_URL,SPLASH_URL
from utils.api_to_redis import user_profile_manager, UserProfileError, deposit_manager, DepositError

from utils.helper import chat_history_helper
from src.graph import app_graph
from utils.HashingApi import (SplashHashing, CustomerserviceHash,DepositHash)
from utils.TokenGeneration import token_manager,csrf_verifier
try:
    from utils.resource_manager import resource_manager
except ImportError as e:
    logging.warning(f"Resource manager not available: {e}")
    class DummyResourceManager:
        async def start_monitoring(self): 
            await asyncio.sleep(0.1)
        async def stop_monitoring(self): pass
        def get_resource_stats(self): return {"status": "unavailable"}
        async def _emergency_cleanup(self): pass
    resource_manager = DummyResourceManager()

from src.classes import (
    ChatRequest, ChatResponse, AgentState, ProfileAndDepositResponse,
    ProfileAndDepositRequest, CacheOperationResponse,
    ChatRequest
)
from fastapi_limiter import FastAPILimiter
from fastapi_limiter.depends import RateLimiter
import redis.asyncio as redis
from utils.encryption import encrypt_data

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Initializes services with CPU throttling to prevent server crashes.
    """
    from utils.startup_throttle import throttle
    
    redis_connection = None
    
    async def init_redis():
        nonlocal redis_connection
        redis_connection = redis.from_url(
            REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
            max_connections=10,  # Reduced from 20
            retry_on_timeout=True
        )
        await FastAPILimiter.init(redis_connection)
        return True
    
    async def init_resource_manager():
        await resource_manager.start_monitoring()
        return True
    
    # Throttled initialization
    try:
        await throttle.throttled_init(init_redis, "Redis")
        logging.info("Redis initialized successfully.")
    except Exception as e:
        logging.critical(f"Redis initialization failed: {e}")
        raise
    
    try:
        await throttle.throttled_init(init_resource_manager, "Resource Manager")
        logging.info("Resource manager started.")
    except Exception as e:
        logging.error(f"Resource manager failed: {e}")
    
    # Post-startup stability check
    await asyncio.sleep(2)
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=1)
        if cpu > 90:
            logging.error(f"CPU too high after startup: {cpu}%")
            raise Exception("Server unstable after initialization")
        logging.info(f"Startup complete. CPU: {cpu}%")
    except ImportError:
        logging.info("Startup complete (psutil not available)")
    
    yield
    
    # Cleanup
    try:
        await resource_manager.stop_monitoring()
    except Exception as e:
        logging.error(f"Error stopping resource manager: {e}")
    
    if redis_connection:
        try:
            await redis_connection.close()
        except Exception as e:
            logging.error(f"Error closing Redis: {e}")

app = FastAPI(
    title="Banking Assistant API", 
    version="1.0.0",
    description="A comprehensive banking assistant API with security features and JWT token authentication",
    lifespan=lifespan,
    docs_url="/docs",  
    redoc_url="/redoc"  
)
 
app.root_path = "/pythonprod-service"

splash_handler = SplashHashing()
customer_handler = CustomerserviceHash()
deposit_handler = DepositHash()

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"

    response.headers["Cross-Origin-Embedder-Policy"] = "require-corp"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    if request.url.path in ["/docs", "/redoc"] or request.url.path.startswith("/openapi"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://unpkg.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; "
            "img-src 'self' data: https: blob:; "
            "font-src 'self' https: data:; "
            "connect-src 'self' https:; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )
    else:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "font-src 'self' https:; "
            "connect-src 'self' https:; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = (
        "camera=(), "
        "microphone=(), "
        "geolocation=(), "
        "payment=(), "
        "usb=(), "
        "magnetometer=(), "
        "gyroscope=(), "
        "speaker=()"
    )
    
    return response

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5001/docs","https://bot.mactech.net.in/wptest/docs"],  
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-CSRF-TOKEN"],
    expose_headers=[
        "Strict-Transport-Security",
        "X-Frame-Options",  
        "X-Content-Type-Options",
        "Content-Security-Policy",
        "Referrer-Policy",
        "Permissions-Policy"
    ]
)


def extract_customer_id_from_profile(profile_data: Optional[Dict[str, Any]]) -> Optional[str]:
    """Extract customer ID from profile data."""
    if not profile_data or not isinstance(profile_data, dict):
        return None
    customers = profile_data.get('customers', [])
    if isinstance(customers, list) and len(customers) > 0:
        return customers[0].get('customerId') or customers[0].get('customerid') or customers[0].get('CustomerId')
    return profile_data.get('customerId') or profile_data.get('customerid') or profile_data.get('CustomerId')


def extract_branch_id_from_deposit(deposit_response: Optional[Dict[str, Any]]) -> Optional[str]:
    """Extract branch ID from deposit response."""
    if not deposit_response or not isinstance(deposit_response, dict):
        return None
    deposits = deposit_response.get('deposits', [])
    if isinstance(deposits, list) and len(deposits) > 0:
        branch_id = deposits[0].get('branchId') or deposits[0].get('branchid')
        return str(branch_id) if branch_id is not None else None
    return None

def encrypt_data_safe(data: Any) -> Optional[Dict[str, Any]]:
    """
            Safely encrypt data with proper error handling and fallback.
    """
    if not data:
        return None
    
    try:
        data_json_str = json.dumps(data, default=str)
        encrypted_result = encrypt_data(data_json_str)
        if encrypted_result and isinstance(encrypted_result, dict):
            logger.info(f"Data encrypted successfully")
            return encrypted_result
        else:
            logger.warning(f"Encryption returned invalid result, returning original data")
            return data 
    except Exception as encrypt_error:
        logger.error(f"Error encrypting data: {encrypt_error}", exc_info=True)
        return data  
    

    
@app.get("/health")
async def health_check():
    try:
        resource_stats = resource_manager.get_resource_stats()
    except Exception:
        resource_stats = {"status": "unavailable"}
    
    return {
        "status": "healthy", 
        "resources": resource_stats,
        "timestamp": datetime.datetime.now().isoformat()
    }

@app.get("/ready")
async def readiness_check():
    try:
        redis_status = "unknown"
        if REDIS_URL:
            test_redis = redis.from_url(REDIS_URL, socket_timeout=2)
            await test_redis.ping()
            await test_redis.close()
            redis_status = "connected"
        
        try:
            resource_stats = resource_manager.get_resource_stats()
        except Exception:
            resource_stats = {"status": "unavailable"}
        
        return {
            "status": "ready",
            "redis": redis_status,
            "resources": resource_stats,
            "timestamp": datetime.datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Service not ready: {str(e)}")


@app.get("/startup-status")
async def startup_status():
    """Check if server started without CPU issues"""
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        memory = psutil.virtual_memory().percent
        
        status = "stable"
        if cpu > 85 or memory > 90:
            status = "unstable"
        
        return {
            "status": status,
            "cpu_percent": cpu,
            "memory_percent": memory,
            "timestamp": datetime.datetime.now().isoformat()
        }
    except ImportError:
        return {"status": "unknown", "message": "psutil not available"}
    
    


@app.post("/fetch-profile-and-deposit", response_model=ProfileAndDepositResponse)
async def fetch_profile_and_deposit(request: ProfileAndDepositRequest,  
                                    limiter: RateLimiter = Depends(RateLimiter(times=5, seconds=60))
):
    """
    Endpoint to fetch and cache both user profile and deposit details using JWT token.

    """
    token = request.stored_token 
    logger.info(f"Received request to fetch profile and deposit details using token")

    phone_number = None
    profile_data = None
    deposit_details = None
    customer_id = None
    jwt_token = None

    try:
        phone_number = token_manager.extract_phone_from_token(token)
        if not phone_number:
            logger.error("Invalid token or failed to extract phone number")
            return ProfileAndDepositResponse(
                success=False,
                message="Invalid authentication token. Please provide a valid JWT token.",
                status="auth_error"
            )
        
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Token validated successfully. Phone number extracted: {masked_phone}")

        logger.info(f"Step 2: Authenticating with Splash API for phone number: {masked_phone}")
        splash_url = SPLASH_URL
        splash_data = {
            "Applicationnumber": "1234",
            "DeviceID": phone_number
        }
        
        splash_success = await splash_handler.send_request(splash_url, splash_data, phone_number)
        
        if not splash_success or not splash_handler.verified_jwt_token:
            logger.error(f"Splash authentication failed for phone number: {masked_phone}")
            return ProfileAndDepositResponse(
                success=False,
                message="Failed to authenticate with Splash API.",
                status="auth_error"
            )
        
        jwt_token = splash_handler.verified_jwt_token
        logger.info(f"Splash authentication successful for phone number: {masked_phone}")
        
        logger.info(f"Step 3: Fetching customer profile for phone number: {masked_phone}")
        try:
            profile_data = await user_profile_manager.get_user_profile_by_phone(
                phone_number=phone_number,
                jwt_token=jwt_token
            )
            logger.info(f"Customer profile fetched and cached successfully for phone number: {masked_phone}")
        except UserProfileError as profile_error:
            logger.error(f"UserProfileError fetching profile for {masked_phone}: {profile_error.message}")
            return ProfileAndDepositResponse(
                success=False,
                message=f"Failed to fetch customer profile: {profile_error.message}",
                status="profile_error"
            )
        except Exception as profile_exc:
            logger.error(f"Unexpected error fetching profile for {masked_phone}: {profile_exc}", exc_info=True)
            return ProfileAndDepositResponse(
                success=False,
                message="Failed to fetch customer profile due to an internal error.",
                status="profile_error"
            )

        customer_id = extract_customer_id_from_profile(profile_data)
        
        if not customer_id:
            logger.warning(f"Customer ID not found in profile data for phone number: {masked_phone}")
            logger.info(f"Profile data keys: {list(profile_data.keys()) if isinstance(profile_data, dict) else 'Not a dict'}")
            
            encrypted_profile_data = encrypt_data_safe(profile_data)
            
            return ProfileAndDepositResponse(
                success=True,
                customer_id=None,
                profile_data=encrypted_profile_data,
                deposit_details=None,
                message="Customer profile fetched successfully. Deposit details require customer ID and are not available.",
                status="profile_only_success",
                has_deposits=False
            )
        
        logger.info(f"Successfully extracted customer ID: {customer_id} for phone number: {masked_phone}")
        
        logger.info(f"Step 5: Customer ID found. Attempting to fetch deposit details for customer ID: {customer_id}")
        
        try:
            deposit_details = await deposit_manager.get_deposit_details_by_phone(
                phone_number=phone_number,
                jwt_token=jwt_token,
                customer_id=customer_id
            )
            
            has_deposits = False
            if deposit_details:
                deposits = deposit_details.get('deposits', [])
                if isinstance(deposits, list) and len(deposits) > 0:
                    has_deposits = True
                    logger.info(f"Found {len(deposits)} deposit records for customer ID: {customer_id}")
                else:
                    logger.info(f"No active deposits found for customer ID: {customer_id}")
                    deposit_details = {
                        "deposits": [],
                        "status": "No deposits found",
                        "customer_id": customer_id,
                        "total_deposits": 0
                    }
            else:
                logger.info(f"No deposit data returned for customer ID: {customer_id}")
                deposit_details = {
                    "deposits": [],
                    "status": "No deposits found",
                    "customer_id": customer_id,
                    "total_deposits": 0
                }
                
        except DepositError as deposit_error:
            logger.warning(f"DepositError for customer ID {customer_id}: {deposit_error.message}")
            deposit_details = {
                "deposits": [],
                "status": f"Deposit fetch failed: {deposit_error.message}",
                "customer_id": customer_id,
                "total_deposits": 0
            }
            has_deposits = False
        except Exception as deposit_exc:
            logger.error(f"Unexpected error fetching deposits for customer ID {customer_id}: {deposit_exc}", exc_info=True)
            deposit_details = {
                "deposits": [],
                "status": f"Deposit fetch failed due to internal error",
                "customer_id": customer_id,
                "total_deposits": 0
            }
            has_deposits = False
        
        encrypted_profile_data = encrypt_data_safe(profile_data)
        encrypted_deposit_details = encrypt_data_safe(deposit_details)
        
        if has_deposits:
            status_message = "Customer profile and deposit details fetched successfully."
            status_code = "full_success"
        else:
            status_message = "Customer profile fetched successfully. No active deposits found."
            status_code = "profile_only_success"
        
        return ProfileAndDepositResponse(
            success=True,
            customer_id=customer_id,
            profile_data=encrypted_profile_data,
            deposit_details=encrypted_deposit_details,
            message=status_message,
            status=status_code,
            has_deposits=has_deposits
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.critical(f"Unexpected error occurred while fetching data for {phone_number}: {e}", exc_info=True)
        
        

@app.delete("/clear-profile-cache/{phone_number}", response_model=CacheOperationResponse)
async def clear_profile_cache(phone_number: str):
    """
    Clears the cached user profile and deposit details for a specific phone number from Redis.
    """
    masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
    logger.info(f"Received request to clear profile and deposit cache for phone_number: {masked_phone}")
    
    if not user_profile_manager or not deposit_manager:
        logger.error("UserProfileManager or DepositManager is not initialized. Cannot process request.")
        raise HTTPException(status_code=500, detail={
            "message": "Service unavailable: Cache managers not initialized.",
            "phone_number": phone_number,
            "status": "error"
        })

    try:
        profile_result = await user_profile_manager.clear_user_profile_cache(phone_number)
        logger.info(f"User profile cache cleared for phone_number: {masked_phone}")

        deposit_result = await deposit_manager.clear_deposit_cache(phone_number)
        logger.info(f"Deposit cache cleared for phone_number: {masked_phone}")

        success = profile_result['success'] and deposit_result['success']
        message = (
            f"Profile and deposit cache for phone_number {masked_phone} cleared successfully."
            if success
            else "Failed to clear one or both caches."
        )
        status_str = "success" if success else "error"

        if not success:
            logger.error(f"Cache clearing failed. Profile result: {profile_result}, Deposit result: {deposit_result}")

        return CacheOperationResponse(
            success=success,
            message=message
        )
        
    except Exception as e:
        logger.critical(f"An unexpected error occurred while clearing caches for {masked_phone}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail={
            "message": f"An unexpected internal error occurred: {str(e)}",
            "phone_number": phone_number,
            "status": "error"
        })



@app.post("/chat", response_model=ChatResponse)
async def chat_with_assistant(request: ChatRequest):
    """
    Interacts with the banking assistant using the LangGraph workflow.

    """
    token = request.stored_token
    user_message = request.user_input
    
    logger.info(f"Received chat message with token authentication: '{user_message}'")

    try:
        phone_number = token_manager.extract_phone_from_token(token)
        if not phone_number:
            logger.error("Invalid token or failed to extract phone number")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "success": False,
                    "message": "Invalid authentication token. Please provide a valid JWT token.",
                    "status": "auth_error"
                }
            )
        
        logger.info(f"Token validated successfully. Phone number extracted: {phone_number}")
        
        session_id = phone_number
        
        logger.info(f"Processing chat message for session {session_id}: '{user_message}'")

        initial_state: AgentState = {
            "input": user_message,
            "session_id": session_id,
            "customer_profile": None,
            "deposit_profile": None,
            "decision": None,
            "response": None,
            "retrieved_documents": None,
            "sd_opening_amount": None,
            "token": token 
        }

        final_state = await app_graph.ainvoke(initial_state)
        ai_response = final_state.get("response")

        if not ai_response:
            logger.warning(f"Graph completed for session {session_id} but no AI response was generated.")
            ai_response = "I'm sorry, I couldn't generate a response for that. Please try again."

        return ChatResponse(
            session_id=session_id,
            ai_response=ai_response,
            status="success"
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.critical(f"Error during chat interaction: {e}", exc_info=True)
        
        try:
            phone_number_for_cleanup = token_manager.extract_phone_from_token(token)
            if phone_number_for_cleanup:
                await chat_history_helper.history.clear_history(phone_number_for_cleanup)
                logger.info(f"Cleared chat history for session {phone_number_for_cleanup} due to critical error.")
            else:
                logger.warning("Could not extract phone number for cleanup after an error.")
        except Exception as cleanup_error:
            logger.error(f"Failed to cleanup chat history: {cleanup_error}")
            
        raise HTTPException(status_code=500, detail={
            "message": "An internal error occurred during processing. Please try again.",
            "error": str(e),
            "status": "error"
        })


@app.post("/admin/cleanup-resources")
async def cleanup_resources():
    """
    Manual resource cleanup endpoint for administrators
    """
    try:
        before_stats = resource_manager.get_resource_stats()
        await resource_manager._emergency_cleanup()
        after_stats = resource_manager.get_resource_stats()
        
        return {
            "status": "success",
            "message": "Resource cleanup completed",
            "before": before_stats,
            "after": after_stats,
            "timestamp": datetime.datetime.now().isoformat()
        }
    except AttributeError:
        raise HTTPException(status_code=503, detail={
            "message": "Resource manager not available"
        })
    except Exception as e:
        logger.error(f"Error during manual resource cleanup: {e}")
        raise HTTPException(status_code=500, detail={
            "message": "Resource cleanup failed",
            "error": str(e)
        })


if __name__ == "__main__":
    logger.info("Starting Banking Assistant API on http://0.0.0.0:5001")
    uvicorn.run(app, host="0.0.0.0", port=5001)