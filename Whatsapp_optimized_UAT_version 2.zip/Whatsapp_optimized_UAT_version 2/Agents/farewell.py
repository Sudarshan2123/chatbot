from langchain_core.messages import AIMessage
from src.classes import AgentState
from utils.helper import (non_banking_helper, format_helper, llm_helper, chat_history_helper)
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class Farewell:
    def __init__(self):
        self.non_banking_helper = non_banking_helper
        self.format_helper = format_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper

    async def Farewell_agent(self,state: AgentState) -> AgentState:
        """
        Provides a polite farewell and terminates the conversation.
        Enhanced with has_deposits awareness for personalized farewell.
        """
        user_input = state.get("input", "")
        session_id = state.get("session_id")
        has_deposits = state.get("has_deposits", False)
        
        if has_deposits:
            farewell_message = "Thank you for banking with us! Your deposits are in safe hands. Have a wonderful day and feel free to reach out whenever you need assistance with your banking needs."
        else:
            farewell_message = "Thank you for banking with us! Consider opening a Savings Deposit (SD) account to start growing your savings. Have a wonderful day and feel free to reach out whenever you need assistance with your banking needs."
        
        if session_id:
            await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=farewell_message)])
            await self.chathistory_helper.history.clear_history(session_id)
        
        logger.info(f"Farewell message sent for session {session_id} (has_deposits: {has_deposits}). Ending conversation.")
        return {**state, "response": farewell_message, "decision": "farewell_end"}