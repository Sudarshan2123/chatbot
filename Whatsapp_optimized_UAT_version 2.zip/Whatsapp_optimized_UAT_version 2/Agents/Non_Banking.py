from langchain_core.messages import AIMessage
from src.classes import AgentState
from utils.helper import (non_banking_helper, format_helper, llm_helper, chat_history_helper)
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class NonBanking:
    def __init__(self):
        self.non_banking_helper = non_banking_helper
        self.format_helper = format_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper

    async def NonMaben_banking_agent(self,state: AgentState) -> AgentState:
        """
        Handles queries about other banks or non-Maben banking information.
        
        """
        user_input = state.get("input", "")
        session_id = state.get("session_id")
        
        response_message = ("I apologize, but I can only provide information about Maben banking services and policies. "
                        "For information about other banks or external banking services, please contact the respective bank directly or visit their official website. "
                        "Is there anything about your Maben banking account or our services that I can help you with?")
        
        if session_id:
            await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=response_message)])
        
        logger.info(f"Non-Maben banking query handled for session {session_id}. Input: '{user_input}'")
        return {**state, "response": response_message, "decision": "conversation_complete"}