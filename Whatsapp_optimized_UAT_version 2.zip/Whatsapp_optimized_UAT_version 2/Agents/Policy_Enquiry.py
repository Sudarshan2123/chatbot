from typing import Dict, Any
from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_google_vertexai import VertexAIEmbeddings
from utils.helper import (non_banking_helper, policy_query_helper, llm_helper, chat_history_helper)
from langchain_community.vectorstores import Chroma
from src.config import CHROMA_DB_PATH, CHROMA_COLLECTION_NAME, embedding_model
import chromadb
import logging

logger = logging.getLogger(__name__)

class PolicyEnquiry:
    """Optimized PolicyEnquiry with proper singleton management."""

    __slots__ = (
        'non_banking_helper',
        'policy_query_helper', 
        'chathistory_helper',
        'llm_helper',
        'CHROMA_DB_PATH',
        'CHROMA_COLLECTION_NAME',
        'Embedding_model'
    )
    
    _shared_embeddings = None
    _shared_chroma_client = None
    _initialization_lock = False
    
    def __init__(self):
        self.non_banking_helper = non_banking_helper
        self.policy_query_helper = policy_query_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper
        self.CHROMA_DB_PATH = CHROMA_DB_PATH
        self.CHROMA_COLLECTION_NAME = CHROMA_COLLECTION_NAME
        self.Embedding_model = embedding_model        
        self._ensure_shared_resources()
    
    @classmethod
    def _ensure_shared_resources(cls):
        """Initialize shared resources once at class level."""
        if cls._initialization_lock:
            return
            
        cls._initialization_lock = True
        
        try:
            if cls._shared_embeddings is None:
                logger.info("Initializing shared VertexAI embeddings...")
                cls._shared_embeddings = VertexAIEmbeddings(model_name=embedding_model)
                logger.info("Shared embeddings initialized")
            
            if cls._shared_chroma_client is None:
                logger.info("Initializing shared ChromaDB client...")
                cls._shared_chroma_client = chromadb.PersistentClient(
                    path=CHROMA_DB_PATH,
                    settings=chromadb.Settings(
                        anonymized_telemetry=False,
                        allow_reset=False, 
                        persist_directory=CHROMA_DB_PATH
                    )
                )
                logger.info("Shared ChromaDB client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize shared resources: {e}", exc_info=True)
            cls._initialization_lock = False
            raise
    
    async def policyinquiry_agent(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Memory-optimized policy inquiry agent."""
        user_input = state.get("input", "")
        session_id = state.get("session_id")

        if state.get("decision") == "terminal_error_response":
            logger.info("Policy inquiry: Terminal error already set")
            return state

        if self.llm_helper.llm is None:
            logger.error("LLM not initialized")
            error_response = "I'm currently unable to access policy information. Please try again later."
            if session_id:
                await self.chathistory_helper.history.add_message_to_history(
                    session_id, [AIMessage(content=error_response)]
                )
            return {**state, "response": error_response, "decision": "terminal_error_response"}

        retrieved_docs = []
        try:
            collection = self._shared_chroma_client.get_collection(
                name=self.CHROMA_COLLECTION_NAME
            )
            
            doc_count = collection.count()
            if doc_count > 0:
                vectorstore = Chroma(
                    client=self._shared_chroma_client,
                    collection_name=self.CHROMA_COLLECTION_NAME,
                    embedding_function=self._shared_embeddings,
                )
                
                docs = vectorstore.similarity_search(user_input, k=min(2, doc_count))
                retrieved_docs = [doc.page_content for doc in docs]
                logger.info(f"Retrieved {len(retrieved_docs)} documents")
            else:
                logger.warning(f"Collection '{self.CHROMA_COLLECTION_NAME}' is empty")

        except Exception as e:
            logger.error(f"ChromaDB retrieval failed: {e}", exc_info=True)
            error_response = "Error accessing policy documents. Please try again later."
            return {**state, "response": error_response, "decision": "terminal_error_response"}

        try:
            chat_history = []
            if session_id:
                try:
                    chat_history = await self.chathistory_helper.history.load_history(
                        session_id, limit=6  
                    )
                except Exception as e:
                    logger.warning(f"Could not load chat history: {e}")

            context = "\n\n".join(retrieved_docs) if retrieved_docs else "No specific policy documents found."

            system_prompt_content = f"""You are a Maben banking policy expert assistant. You help users understand Maben banking policies, terms, conditions, and procedures.

STRICT RESPONSE RULES:
- DO NOT return database schemas, table formats, SQL queries, or any technical metadata.
- DO NOT mention or reference "documents" or "policy documents" in responses.
- When asked "What data do you have?" respond ONLY with: "I have access to Maben policies."
- DO NOT interpret or summarize raw identifiers unless their meaning is explicitly explained in the context.
- DO NOT provide general banking knowledge or assumptions.
- If the context does not contain the requested information, clearly state: "The context does not contain that information."

Context from Policy Documents:
{context}

Answer the user's question ONLY based on the above context. If the context doesn't contain the specific information requested, respond with "I don't have specific information about [topic] in our current policy database. Please contact customer support for detailed information."
"""

            prompt_template = ChatPromptTemplate.from_messages([
                ("system", system_prompt_content),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}")
            ])

            chain = prompt_template | self.llm_helper.llm
            response = await chain.ainvoke({
                "input": user_input,
                "chat_history": chat_history
            })

            response_content = response.content
            logger.info(f"Generated policy response: {response_content[:100]}...")

            if session_id:
                try:
                    await self.chathistory_helper.history.add_message_to_history(
                        session_id, [AIMessage(content=response_content)]
                    )
                except Exception as e:
                    logger.warning(f"Could not save to chat history: {e}")

            return {
                **state,
                "response": response_content,
                "retrieved_documents": retrieved_docs[:2],  
                "decision": "conversation_complete"
            }

        except Exception as e:
            logger.error(f"Error generating LLM response: {e}", exc_info=True)
            error_response = "I apologize, I encountered an error. Please try again or contact support."

            if session_id:
                try:
                    await self.chathistory_helper.history.add_message_to_history(
                        session_id, [AIMessage(content=error_response)]
                    )
                except Exception as hist_e:
                    logger.warning(f"Could not save error to chat history: {hist_e}")

            return {**state, "response": error_response, "decision": "terminal_error_response"}
    
    @classmethod
    def cleanup_shared_resources(cls):
        """Cleanup method for graceful shutdown."""
        if cls._shared_chroma_client:
            try:
                cls._shared_chroma_client = None
                logger.info("ChromaDB client cleaned up")
            except Exception as e:
                logger.error(f"Error cleaning up ChromaDB: {e}")
        
        cls._shared_embeddings = None
        cls._initialization_lock = False

