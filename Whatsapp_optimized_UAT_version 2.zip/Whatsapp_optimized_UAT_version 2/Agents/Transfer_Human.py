from langchain_core.messages import AIMessage
from src.classes import AgentState
from utils.helper import (non_banking_helper, format_helper, llm_helper, chat_history_helper)
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TransferHuman:
    def __init__(self):
        self.non_banking_helper = non_banking_helper
        self.format_helper = format_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper

    async def Transfer_to_Human_agent(self,state: AgentState) -> AgentState:
        """
        Informs the user that they are being transferred to a human agent.
        
        """
        user_input = state.get("input", "")
        session_id = state.get("session_id")
        has_deposits = state.get("has_deposits", False)
        
        if has_deposits:
            transfer_message = "I'm your Maben Banking assistant, ready to assist with any banking inquiries about your account and deposits. Please ask about Maben Banking services, your deposit details, or account information."
        else:
            transfer_message = "I'm your Maben Banking assistant, ready to assist with any banking inquiries. I can help with account information, banking policies, or assist you in opening a new Savings Deposit (SD) account. Please ask about Maben Banking services."
        
        if session_id:
            await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=transfer_message)])
            await self.chathistory_helper.history.clear_history(session_id)
        
        logger.info(f"Transferring to human agent (via branch visit message) for session {session_id} (has_deposits: {has_deposits}).")
        return {**state, "response": transfer_message, "decision": "transfer_end"}