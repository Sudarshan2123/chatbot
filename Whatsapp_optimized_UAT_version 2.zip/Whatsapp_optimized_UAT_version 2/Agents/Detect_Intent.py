from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from src.classes import AgentState
from utils.helper import (
    token_helper, confirmation_helper,
    cancellation_helper, non_banking_helper,
    policy_query_helper, format_helper,
    deposit_helper, sd_helper,
    llm_helper,
    chat_history_helper, user_profile_helper
)
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class DetectIntent:

    __slots__ = (
        'token_helper',
        'confirmation_helper',
        'cancellation_helper',
        'non_banking_helper',
        'policy_query_helper',
        'format_helper',
        'deposit_helper',
        'user_profile_helper',
        'chathistory_helper',
        'llm_helper',
        'sd_helper'
    )
    
    def __init__(self):
        self.token_helper = token_helper
        self.confirmation_helper = confirmation_helper
        self.cancellation_helper = cancellation_helper
        self.non_banking_helper = non_banking_helper
        self.policy_query_helper = policy_query_helper
        self.format_helper = format_helper
        self.deposit_helper = deposit_helper
        self.user_profile_helper = user_profile_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper
        self.sd_helper = sd_helper

    async def detect_intent(self,state: AgentState) -> AgentState:
        """
        Detects the user's intent based on the input with improved rule-based detection.
        """
        user_input = state.get("input", "")
        session_id = state.get("session_id")
        
        if state.get("decision") == "terminal_error_response":
            logger.info("Detect intent: Terminal error response already set. Bypassing LLM.")
            return state

        if llm_helper.llm is None:
            logger.error("LLM not initialized. Cannot detect intent.")
            error_response = "I'm currently experiencing technical difficulties. Please try again later."
            if session_id:
                await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=error_response)])
            return {**state, "decision": "terminal_error_response", "response": error_response}

        user_input_lower = user_input.lower().strip()
        
        if non_banking_helper.is_non_maben_banking_query(user_input):
            logger.info(f"Rule-based detection: Non-Maben banking query detected for input: '{user_input}'")
            return {**state, "decision": "non_maben_banking_route"}
        
        personal_info_keywords = [
            'my pan', 'my pancard', 'my account number', 'my balance', 'my name', 
            'my phone', 'my deposits', 'my deposit details', 'my customer id',
            'what is my', 'show my', 'tell me my', 'my profile', 'my information',
            'account details', 'deposit amount', 'deposit balance', 'maturity amount',
            'pancard number', 'pan number'
        ]
        
        if any(keyword in user_input_lower for keyword in personal_info_keywords):
            logger.info(f"Rule-based detection: Intent 'account_details' for input: '{user_input}'")
            if not state.get("customer_profile"):
                logger.warning("User asked for account/deposit details but no customer profile available.")
                state["response"] = "I can't provide account or deposit details right now because I couldn't access your profile. Please ensure you've provided your registered phone number correctly."
                return {**state, "decision": "transfer_to_human_route"}
            return {**state, "decision": "account_details_route"}
        
        greeting_patterns = [
            "hello", "hi", "hey","hai","hy", "good morning", "good afternoon", "good evening", 
            "greetings", "howdy", "hiya", "sup", "namaste"
        ]
        
        words = user_input_lower.split()
        
        if len(words) == 1 and words[0] in greeting_patterns:
            logger.info(f"Rule-based detection: Intent 'greeting' for input: '{user_input}'")
            return {**state, "decision": "greeting_route"}
        
        if len(words) == 2 and user_input_lower in ["good morning", "good afternoon", "good evening", "what's up"]:
            logger.info(f"Rule-based detection: Intent 'greeting' for input: '{user_input}'")
            return {**state, "decision": "greeting_route"}
        
        if len(words) <= 2:
            cleaned_input = user_input_lower.replace("!", "").replace(".", "").replace(",", "").strip()
            if cleaned_input in greeting_patterns or cleaned_input in ["hi there", "hello there"]:
                logger.info(f"Rule-based detection: Intent 'greeting' for input: '{user_input}'")
                return {**state, "decision": "greeting_route"}
    
        
        farewell_keywords = ["bye", "goodbye", "see you", "goodnight", "thank you", "thanks"]
        if any(keyword in user_input_lower for keyword in farewell_keywords):
            logger.info(f"Rule-based detection: Intent 'farewell' for input: '{user_input}'")
            return {**state, "decision": "farewell_route"}
        
        human_keywords = ["human", "agent", "support", "talk to someone", "speak to agent"]
        if any(keyword in user_input_lower for keyword in human_keywords):
            logger.info(f"Rule-based detection: Intent 'transfer_to_human' for input: '{user_input}'")
            return {**state, "decision": "transfer_to_human_route"}
        
        if policy_query_helper.is_policy_related_query(user_input):
            logger.info(f"Rule-based detection: Intent 'policy_inquiry' for input: '{user_input}'")
            return {**state, "decision": "policy_inquiry_route"}

        chat_history = []
        if session_id:
            chat_history = await self.chathistory_helper.history.load_history(session_id)
        
        prompt_template = ChatPromptTemplate.from_messages([
            ("system", """
                You are an intent detection model for a Maben banking chatbot. Your task is to classify the user's query into one of the following categories. Respond ONLY with the exact keyword of the category.
                
                Categories and their definitions:
                - 'greeting': Simple greetings like "hello", "hi", "good morning" WITHOUT any specific requests or questions.
                - 'account_details': Queries about PERSONAL information like "my PAN card", "my account number", "my balance", "my deposits", "my profile", or any request for user's own banking data.
                - 'policy_inquiry': Queries about GENERAL Maben banking policies, terms, conditions, procedures, eligibility requirements, or general banking information (NOT personal data).
                - 'farewell': Explicit goodbyes or thanks.
                - 'non_maben_banking': Queries about other banks (SBI, HDFC, ICICI, etc.) or non-Maben banking information.
                - 'transfer_to_human': Requests to speak to a human or unclear queries that don't fit other categories.

                Important: 
                - If query contains greeting + specific request (e.g. "hi what is my pancard"), classify based on the REQUEST, not the greeting.
                - If the query asks for "my [something]" or personal account information, classify as 'account_details', NOT 'policy_inquiry'.
                - If the query mentions other banks or non-Maben banking services, classify as 'non_maben_banking'.

                Input: {input}
                Output a single keyword corresponding to the intent.
                """),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}")
        ])
        
        chain = prompt_template | llm_helper.llm
        
        decision_to_make = "transfer_to_human_route"
        try:
            response = await chain.ainvoke({
                "input": user_input,
                "chat_history": chat_history
            })
            detected_intent = response.content.strip().lower()
            logger.info(f"LLM detected intent: '{detected_intent}' for input: '{user_input}'")

            valid_intents = ["greeting", "account_details", "policy_inquiry", "farewell", "non_maben_banking", "transfer_to_human"]
            if detected_intent not in valid_intents:
                logger.warning(f"Invalid intent '{detected_intent}' from LLM. Defaulting to 'transfer_to_human_route'.")
                detected_intent = "transfer_to_human"

            if detected_intent == "greeting":
                decision_to_make = "greeting_route"
            elif detected_intent == "account_details":
                if not state.get("customer_profile"):
                    logger.warning("User asked for account details but no customer profile available.")
                    state["response"] = "I can't provide account details right now because I couldn't access your profile. Please ensure you've provided your registered phone number correctly."
                    decision_to_make = "transfer_to_human_route"
                else:
                    decision_to_make = "account_details_route"
            elif detected_intent == "policy_inquiry":
                decision_to_make = "policy_inquiry_route"
            elif detected_intent == "farewell":
                decision_to_make = "farewell_route"
            elif detected_intent == "non_maben_banking":
                decision_to_make = "non_maben_banking_route"
            elif detected_intent == "transfer_to_human":
                decision_to_make = "transfer_to_human_route"

            return {**state, "decision": decision_to_make}
        except Exception as e:
            logger.error(f"Error in LLM intent detection for '{user_input}': {e}", exc_info=True)
            error_response = "I apologize, I'm having trouble understanding your request right now. Could you please rephrase or try again?"
            if session_id:
                await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=error_response)])
            return {**state, "decision": "terminal_error_response", "response": error_response}