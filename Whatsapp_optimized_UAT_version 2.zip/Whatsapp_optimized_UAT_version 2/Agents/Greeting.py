from langchain_core.messages import AIMessage
from src.classes import AgentState
from utils.helper import (non_banking_helper, format_helper, llm_helper, chat_history_helper)
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class Greetings:
    def __init__(self):
        self.non_banking_helper = non_banking_helper
        self.format_helper = format_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper
    
    async def greeting_agent(self,state: AgentState) -> AgentState:
        """
        Handles greeting messages and provides a welcoming response with available options.
        Enhanced with has_deposits awareness for personalized greetings.
        """
        user_input = state.get("input", "")
        session_id = state.get("session_id")
        customer_profile = state.get("customer_profile")
        has_deposits = state.get("has_deposits", False)
        
        customer_name = ""
        if customer_profile:
            customer_name = customer_profile.get("customerName", "")
            if customer_name:
                customer_name = f" {customer_name.split()[0]}"  
        
        deposit_status_msg = ""
        if customer_profile:
            if has_deposits:
                deposit_status_msg = "\n• View your deposit details and balances"
            else:
                deposit_status_msg = "\n• Open a new Savings Deposit (SD) account (minimum ₹100)"
        
        greeting_message = f"""Hello{customer_name}!
        
    Welcome to our Maben banking assistant. 🏦

    I'm here to help you with:
    • Account and deposit information
    • PAN card, balance{deposit_status_msg}   
    • Banking policies and procedures

    How can I assist you today?"""
        
        if session_id:
            await self.chathistory_helper.history.add_message_to_history(session_id, [AIMessage(content=greeting_message)])
        
        logger.info(f"Greeting message sent for session {session_id}, has_deposits: {has_deposits}")
        return {**state, "response": greeting_message, "decision": "conversation_complete"}