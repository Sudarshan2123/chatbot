from typing import Optional, Dict, Any
from langchain_core.messages import HumanMessage, AIMessage
from src.classes import AgentState
from utils.helper import (
    token_helper,
    confirmation_helper, 
    cancellation_helper, 
    non_banking_helper, 
    policy_query_helper, 
    format_helper,
    deposit_helper,
    chat_history_helper, 
    user_profile_helper 
)
from utils.api_to_redis import UserProfileError, DepositError, deposit_manager
import json
import logging

from utils.TokenGeneration import TokenManagement
token_manager = TokenManagement()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class DataFetcher:
    """
    Contains only one method: fetch_user_and_deposit_data
    Uses helpers: token, manager, format
    Uses global: deposit_manager
    """
    __slots__ = (
        'token_helper',
        'confirmation_helper',
        'cancellation_helper',
        'non_banking_helper',
        'policy_query_helper',
        'format_helper',
        'deposit_helper',
        'user_profile_helper',
        'chathistory_helper',
        'token_manager'
    )

    def __init__(self):
        self.token_helper = token_helper
        self.confirmation_helper = confirmation_helper
        self.cancellation_helper = cancellation_helper
        self.non_banking_helper = non_banking_helper
        self.policy_query_helper = policy_query_helper
        self.format_helper = format_helper
        self.deposit_helper = deposit_helper
        self.user_profile_helper = user_profile_helper 
        self.chathistory_helper = chat_history_helper
        self.token_manager = token_manager

    async def Data_fetcher(self, state: AgentState) -> AgentState:
        """
        Fetches both customer profile and deposit data using only the token.
        Extracts phone number from token and uses it to fetch the details.
        Enhanced with better token management.
        """
        user_input = state.get("input", "")
        token = state.get("token")
        
        profile_data: Optional[Dict[str, Any]] = None
        deposit_data: Optional[Dict[str, Any]] = None
        response_message = None
        decision_to_make = None
        phone_number = None

        if not token:
            logger.warning("No token provided for authentication.")
            response_message = "Authentication token is required to fetch your banking details. Please provide a valid token."
            decision_to_make = "terminal_error_response"
        else:
            phone_number = token_manager.extract_phone_from_token(token)
            
            if not phone_number:
                logger.error(f"Failed to extract phone number from token.")
                response_message = "Invalid token. Unable to extract phone number from the provided token."
                decision_to_make = "terminal_error_response"
            else:
                
                state["session_id"] = phone_number
                
                await chat_history_helper.history.add_message_to_history(phone_number, [HumanMessage(content=user_input)])
                
                if not self.user_profile_helper:
                    logger.error("UserProfileManager not initialized. Cannot fetch customer data.")
                    response_message = "I'm sorry, I cannot access customer data at this moment due to a system issue. Please try again later."
                    decision_to_make = "terminal_error_response"
                else:
                    try:
                        logger.info(f"Attempting to fetch profile for phone number: {phone_number} with token.")
                        profile_data_response = await self.user_profile_helper.profile.get_user_profile_by_phone(phone_number, token)
                        if profile_data_response and profile_data_response.get('customers'):
                            profile_data = profile_data_response['customers'][0]
                            logger.info(f"Successfully loaded profile for phone number: {phone_number}. Profile: {json.dumps(profile_data, default=str)[:500]}...")
                        else:
                            logger.warning(f"Could not find valid profile for phone number: {phone_number}.")
                            response_message = f"I couldn't find any banking profiles associated with the phone number '{phone_number}'. Please ensure it's a registered phone number."
                            decision_to_make = "terminal_error_response"
                    except UserProfileError as e:
                        logger.error(f"UserProfileError fetching profile for {phone_number}: {e.message}", exc_info=True)
                        response_message = f"There was an issue retrieving your profile using '{phone_number}': {e.message}. Please try again later."
                        decision_to_make = "terminal_error_response"
                    except Exception as e:
                        logger.error(f"Unexpected error fetching profile for {phone_number}: {e}", exc_info=True)
                        response_message = "An unexpected error occurred while trying to access your profile. Please try again later."
                        decision_to_make = "terminal_error_response"

                if not response_message:  
                    if not deposit_manager:
                        logger.error("DepositManager not initialized. Cannot fetch deposit data.")
                        response_message = "I'm sorry, I cannot access deposit data at this moment due to a system issue. Please try again later."
                        decision_to_make = "terminal_error_response"
                    else:
                        try:
                            logger.info(f"Attempting to fetch deposit details for phone number: {phone_number} with token.")
                            deposit_data_response = await deposit_manager.get_deposit_details_by_phone(phone_number, token)
                            if deposit_data_response:
                                deposit_data = deposit_data_response
                                logger.info(f"Loaded deposit details for phone number: {phone_number}. Response: {json.dumps(deposit_data, default=str)[:500]}...")
                                if not deposit_data.get("deposits"):
                                    logger.info(f"No deposits found in initial fetch for {phone_number}. Attempting to refresh.")
                                    if hasattr(deposit_manager, 'refresh_deposit_details'):
                                        deposit_data_response = await deposit_manager.refresh_deposit_details(phone_number, token=token)
                                        deposit_data = deposit_data_response if deposit_data_response else {"deposits": [], "status": "No deposits found"}
                                        logger.info(f"Refreshed deposit details for phone number: {phone_number}. Response: {json.dumps(deposit_data, default=str)[:500]}...")
                            else:
                                logger.info(f"No deposit details found for phone number: {phone_number}.")
                                deposit_data = {
                                    "deposits": [],
                                    "status": "No deposits found"
                                }
                        except DepositError as e:
                            logger.error(f"DepositError fetching deposit details for {phone_number}: {e.message}", exc_info=True)
                            response_message = f"There was an issue retrieving your deposit details using '{phone_number}': {e.message}. Please try again later."
                            decision_to_make = "terminal_error_response"
                        except Exception as e:
                            logger.error(f"Unexpected error fetching deposit details for {phone_number}: {e}", exc_info=True)
                            response_message = "An unexpected error occurred while trying to access your deposit details. Please try again later."
                            decision_to_make = "terminal_error_response"

        if response_message:
            if phone_number:
                await chat_history_helper.history.add_message_to_history(phone_number, [AIMessage(content=response_message)])
            return {
                **state,
                "customer_profile": profile_data,
                "deposit_profile": deposit_data,
                "response": response_message,
                "decision": decision_to_make
            }
        
        sd_amount = self.format_helper.extract_amount(user_input)
        
        return {
            **state,
            "customer_profile": profile_data,
            "deposit_profile": deposit_data,
            "sd_opening_amount": sd_amount,
            "decision": "detect_intent_route"
        }
        