from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from src.classes import AgentState
from utils.helper import (
    token_helper, non_banking_helper,
    policy_query_helper, format_helper,
    deposit_helper, llm_helper,
    chat_history_helper, user_profile_helper
)
from utils.api_to_redis import  DepositError, deposit_manager
import json
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class AccountDetails:
    __slots__ = (
        'token_helper',
        'non_banking_helper',
        'policy_query_helper',
        'format_helper',
        'deposit_helper',
        'user_profile_helper',
        'chathistory_helper',
        'llm_helper'
    )

    def __init__(self):
        self.token_helper = token_helper
        self.non_banking_helper = non_banking_helper
        self.policy_query_helper = policy_query_helper
        self.format_helper = format_helper
        self.deposit_helper = deposit_helper
        self.user_profile_helper = user_profile_helper
        self.chathistory_helper = chat_history_helper
        self.llm_helper = llm_helper
    
    async def accountdetails_agent(self,state: AgentState) -> AgentState:
        """
        Handles queries related to both customer profile and deposit details.
        """
        customer_profile = state.get("customer_profile")
        deposit_profile = state.get("deposit_profile")
        user_input = state["input"]
        session_id = state.get("session_id")

        if state.get("decision") == "terminal_error_response":
            logger.info("Account details agent: Passing through pre-set terminal response.")
            return state

        if not customer_profile:
            response_message = "I'm sorry, I couldn't retrieve your account details. Please ensure your account is active or contact support."
            logger.warning(f"account_details_agent called but no valid customer_profile available for input: {user_input}")
            if session_id:
                await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=response_message)])
            return {**state, "response": response_message, "decision": "conversation_complete"}

        if not deposit_profile or not deposit_profile.get("deposits"):
            logger.info(f"No deposits found in cache for phone {session_id}. Attempting to refresh deposit details.")
            try:
                deposit_data_response = await deposit_manager.refresh_deposit_details(session_id, token=state.get("token"))
                deposit_profile = deposit_data_response if deposit_data_response else {"deposits": [], "status": "No deposits found"}
                logger.info(f"Refreshed deposit details for phone {session_id}: {json.dumps(deposit_profile, default=str)[:500]}...")
            except DepositError as e:
                logger.error(f"Failed to refresh deposit details for {session_id}: {e.message}", exc_info=True)
                response_message = f"Unable to fetch deposit details: {e.message}. Please try again or contact support."
                if session_id:
                    await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=response_message)])
                return {**state, "response": response_message, "decision": "terminal_error_response"}

        if llm_helper.llm is None:
            logger.error("LLM not initialized. Cannot generate account details response.")
            error_response = "I'm unable to access account details due to a system issue. Please try again later."
            if session_id:
                await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=error_response)])
            return {**state, "response": error_response, "decision": "terminal_error_response"}

        try:
            chat_history = []
            if session_id:
                chat_history = await chat_history_helper.history.load_history(session_id)

            customer_data = customer_profile.copy()
            if 'dob' in customer_data:
                customer_data['dob_formatted'] = format_helper.format_date(customer_data['dob'])

            deposit_data = deposit_profile.copy() if deposit_profile else {"deposits": [], "status": "No deposits found"}
            deposits = deposit_data.get("deposits", []) or deposit_data.get("depositDetails", [])
            
            if deposits:
                formatted_deposits = []
                total_investment = 0
                total_maturity = 0
                
                for deposit in deposits:
                    deposit_amount = deposit.get("depositAmount", deposit.get("depositamount", 0))
                    maturity_amount = deposit.get("maturityAmount", deposit.get("maturityamount", 0))
                    
                    formatted_deposit = {
                        "branchId": deposit.get("branchId", deposit.get("branchid")),
                        "customerId": deposit.get("customerId", deposit.get("customerid")),
                        "depositId": deposit.get("depositId", deposit.get("depositid")),
                        "customerName": deposit.get("customerName", deposit.get("customername")),
                        "depositAmount": deposit_amount,
                        "depositDate": deposit.get("depositDate", deposit.get("depositdate")),
                        "maturityDate": deposit.get("maturityDate", deposit.get("maturitydate")),
                        "maturityAmount": maturity_amount,
                        "depositPeriod": deposit.get("depositPeriod", deposit.get("depositperiod")),
                        "depositType": deposit.get("depositType", deposit.get("deposittype")),
                        "interestRate": deposit.get("interestRate", deposit.get("interestrate"))
                    }
                    formatted_deposits.append(formatted_deposit)
                    total_investment += deposit_amount
                    total_maturity += maturity_amount
                
                deposit_data["deposits"] = formatted_deposits
                deposit_data["total_deposits"] = len(formatted_deposits)
                deposit_data["total_investment"] = f"₹{total_investment:,.2f}"
                deposit_data["total_maturity"] = f"₹{total_maturity:,.2f}"
                deposit_data["expected_returns"] = f"₹{(total_maturity - total_investment):,.2f}"
            else:
                response_message = "You currently have no active deposits. Would you like to open a Savings Deposit (SD) account with a minimum of ₹100?"
                logger.info(f"No deposits found for phone {session_id} after refresh.")
                if session_id:
                    await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=response_message)])
                return {**state, "response": response_message, "decision": "conversation_complete"}

            combined_data = {
                "customer_data": customer_data,
                "deposit_data": deposit_data
            }
            combined_data_json_str = json.dumps(combined_data, indent=2, default=str)
            logger.info(f"Combined data prepared for LLM: {combined_data_json_str[:500]}...")

            system_prompt_content = """
            You are an intelligent financial assistant helping users understand their Maben banking information.
            **Customer and Deposit Data:**
            ```json
            {combined_data}
            ```

            Provide a clear and concise response to the user's query, which may involve customer details (e.g., name, PAN, account number) or deposit details (e.g., deposit amount, type, maturity).
            Use the provided data to answer accurately. If the query relates to deposits and no deposits exist, state that no deposits are available and suggest opening a savings deposit (SD) account with a minimum of ₹100.
            Format monetary amounts with the Indian Rupee symbol (₹) and use commas for readability.
            """
            
            prompt_template = ChatPromptTemplate.from_messages([
                ("system", system_prompt_content),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}")
            ])
            
            chain = prompt_template | llm_helper.llm
            
            response = await chain.ainvoke({
                "input": user_input,
                "chat_history": chat_history,
                "combined_data": combined_data_json_str
            })
            
            response_content = response.content
            logger.info(f"LLM generated account details response for '{user_input}': {response_content[:200]}...")
            
            if session_id:
                await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=response_content)])
            
            return {**state, "response": response_content, "decision": "conversation_complete"}
            
        except Exception as e:
            logger.error(f"Error in account details generation for '{user_input}': {e}", exc_info=True)
            error_response = "I apologize, I encountered an error while retrieving your account details. Please try again or contact support."
            if session_id:
                await chat_history_helper.history.add_message_to_history(session_id, [AIMessage(content=error_response)])
            return {**state, "response": error_response, "decision": "terminal_error_response"}