import logging
from src.classes import AgentState
from Agents import Data_Fetcher,Non_Banking,Greeting,farewell,Transfer_Human,Policy_Enquiry,Account_Details,Detect_Intent
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


async def greeting_agent(state: AgentState) -> AgentState:
    """Wrapper for the Greetings.greeting_agent method. Exactly parallel to the SD wrappers. """
    greeter = Greeting.Greetings()          
    return await greeter.greeting_agent(state)


async def fetch_user_and_deposit_data(state: AgentState) -> AgentState:
    """Wrapper for DataFetcher.fetch_user_and_deposit_data."""
    fetcher_instance = Data_Fetcher.DataFetcher()
    return await fetcher_instance.Data_fetcher(state)

async def account_details_agent(state: AgentState) -> AgentState:
    """Wrapper for account details agent."""
    Account_Details_instance = Account_Details.AccountDetails()
    return await Account_Details_instance.accountdetails_agent(state)


async def policy_inquiry_agent(state: AgentState) -> AgentState:
    """Wrapper for policy_inquiry_agent."""
    policy_Enquiry_instance = Policy_Enquiry.PolicyEnquiry()
    return await policy_Enquiry_instance.policyinquiry_agent(state)


async def detect_intent(state: AgentState) -> AgentState:
    """Wrapper for detect_intent."""
    Detect_intent_instance = Detect_Intent.DetectIntent()
    return await Detect_intent_instance.detect_intent(state)


async def non_maben_banking_agent(state: AgentState) -> AgentState:
    """Wrapper for non_maben_banking_agent."""
    non_maben_banking_instance = Non_Banking.NonBanking()
    return await non_maben_banking_instance.NonMaben_banking_agent(state)


async def transfer_to_human_agent(state: AgentState) -> AgentState:
    """Wrapper for transfer_to_human_agent."""
    Transfer_to_Human_agent_instance = Transfer_Human.TransferHuman()
    return await Transfer_to_Human_agent_instance.Transfer_to_Human_agent(state)


async def farewell_agent(state: AgentState) -> AgentState:
    """Wrapper for farewell_agent."""
    Farewell_agent_instance = farewell.Farewell()
    return await Farewell_agent_instance.Farewell_agent(state)


