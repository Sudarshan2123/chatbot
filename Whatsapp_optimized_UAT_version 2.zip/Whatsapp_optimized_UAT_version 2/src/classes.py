from typing import List, Optional, Dict, Any, TypedDict
from pydantic import BaseModel, Field, field_validator
import re


class DepositRecord(BaseModel):
    """Model for individual deposit records."""
    deposit_id: str
    account_number: str
    deposit_type: str
    balance: float
    interest_rate: float
    maturity_date: Optional[str] = None
    status: str


class UserProfile(BaseModel):
    """Model for complete user profile with customer and deposit data."""
    customer_id: str
    name: str
    phone_number: str
    email: Optional[str] = None
    address: Optional[str] = None
    account_status: str
    deposits: List[DepositRecord] = Field(default_factory=list)
    total_balance: float = 0.0
    last_updated: Optional[str] = None


class AgentState(TypedDict):
    input: str
    session_id: Optional[str] 
    customer_profile: Optional[Dict[str, Any]]
    deposit_profile: Optional[Dict[str, Any]]
    decision: Optional[str]
    response: Optional[str]
    retrieved_documents: Optional[List[str]]
    sd_opening_amount: Optional[float]
    token: Optional[str]



class PhoneNumberRequest(BaseModel):
    """Request model for fetching profiles by phone number."""
    phone_number: str

    @field_validator("phone_number")  
    @classmethod
    def validate_phone_number(cls, v: str) -> str:
        v = v.strip()
        if not re.fullmatch(r"^\d{10,15}$", v):
            raise ValueError("Phone number must be 10-15 digits.")
        return v


class ChatResponse(BaseModel):
    """Response model for the chat endpoint."""
    session_id: str
    ai_response: str
    status: str
    error: Optional[str] = None


class SDOpeningRequest(BaseModel):
    """Request model for opening an SD account."""
    session_id: str = Field(..., description="The user's registered phone number, used as session ID.")
    amount: float = Field(..., gt=0, description="The amount to deposit for the SD account (minimum ₹100).")

    @field_validator("session_id")
    @classmethod
    def validate_session_id_is_phone_number(cls, v: str) -> str:
        v = v.strip()
        if not re.fullmatch(r"^\d{10,15}$", v):
            raise ValueError("Session ID must be a valid phone number (10-15 digits).")
        return v

    @field_validator("amount")
    @classmethod
    def validate_amount(cls, v: float) -> float:
        if v < 100:
            raise ValueError("The minimum amount to open an SD account is ₹100.")
        return v


class SDOpeningResponse(BaseModel):
    """Response model for the SD opening endpoint."""
    session_id: str
    message: str
    status: str
    error: Optional[str] = None


class HashingApiResponse(BaseModel):
    """Response model for the new Hashing API endpoint."""
    status: str
    message: str
    jwt_token: Optional[str] = None
    phone_number: str


class ProfileAndDepositResponse(BaseModel):
    success: bool
    customer_id: Optional[str] = None
    profile_data: Optional[Dict[str, Any]] = None
    deposit_details: Optional[Dict[str, Any]] = None
    message: str
    status: str


class ProfileAndDepositRequest(BaseModel):
    stored_token: str = Field(..., description="JWT authentication token containing user identification")


class CacheOperationResponse(BaseModel):
    success: bool
    message: str


class ChatRequest(BaseModel):
    stored_token: str = Field(..., description="JWT authentication token containing user identification")
    user_input: str = Field(..., description="User's message/query to the banking assistant")


class EncryptedData(BaseModel):
    """Model for encrypted data containing ciphertext, IV, and authentication tag"""
    encrypted_data: str
    iv: str
    tag: str


class UserProfileError(Exception):
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class DepositError(Exception):
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class SecurityError(Exception):
    def __init__(self, message: str, status_code: int = 403):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class Customer(BaseModel):
    branchid: int
    customerId: str
    customerName: str
    phoneNumber1: Optional[str] = None
    phoneNumber2: Optional[str] = None
    phoneNumber: Optional[str] = None
    fatherHusband: str
    houseName: str
    locality: str
    sharecount: int
    pannumber: str
    dob: str
    ifsccode: str
    beneficiaryBranch: str
    beneficiaryAccount: str
    bankid: int


class Deposit(BaseModel):
    branchId: int
    customerid: str
    depositId: str
    customername: str
    depositamount: float
    depositdate: str
    maturityDate: str
    maturityAmount: float
    depositperiod: int
    deposittype: str
    interestrate: float


class ApiResponseData(BaseModel):
    status: str
    customers: List[Customer] = Field(default_factory=list)
    deposit: List[Deposit] = Field(default_factory=list)


class ApiResponse(BaseModel):
    Data: ApiResponseData
    JWTToken: str
    DeviceToken: str
