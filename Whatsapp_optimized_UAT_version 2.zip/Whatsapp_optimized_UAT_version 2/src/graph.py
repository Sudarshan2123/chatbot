import logging
from langgraph.graph import StateGraph, END

from src.agent import (
    AgentState,
    fetch_user_and_deposit_data,
    detect_intent,
    greeting_agent,
    account_details_agent,
    policy_inquiry_agent,
    farewell_agent,
    transfer_to_human_agent,
    non_maben_banking_agent  # Import the non_maben_banking_agent
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Define the LangGraph Workflow ---
workflow = StateGraph(AgentState)

# Add nodes for each agent function
logger.info("Adding nodes to the LangGraph workflow...")
workflow.add_node("fetch_user_and_deposit_data", fetch_user_and_deposit_data)
workflow.add_node("detect_intent", detect_intent)
workflow.add_node("greeting_agent", greeting_agent)
workflow.add_node("policy_inquiry_agent", policy_inquiry_agent)
workflow.add_node("account_details_agent", account_details_agent)
workflow.add_node("farewell_agent", farewell_agent)
workflow.add_node("transfer_to_human_agent", transfer_to_human_agent)
workflow.add_node("non_maben_banking_agent", non_maben_banking_agent)  # Add the non-Maben banking agent node
logger.info("Nodes added.")

# Set the entry point for the graph
logger.info("Setting entry point for the workflow: fetch_user_and_deposit_data.")
workflow.set_entry_point("fetch_user_and_deposit_data")

# Define conditional edges based on the 'decision' field in the state
logger.info("Defining conditional edges for the workflow.")

# Conditional edge from fetch_user_and_deposit_data
workflow.add_conditional_edges(
    "fetch_user_and_deposit_data",
    lambda state: state["decision"],
    {
        "detect_intent_route": "detect_intent",
        "terminal_error_response": END
    }
)

# Conditional edge from detect_intent
workflow.add_conditional_edges(
    "detect_intent",
    lambda state: state["decision"],
    {
        "greeting_route": "greeting_agent",
        "policy_inquiry_route": "policy_inquiry_agent",
        "account_details_route": "account_details_agent",
        "farewell_route": "farewell_agent",
        "transfer_to_human_route": "transfer_to_human_agent",
        "non_maben_banking_route": "non_maben_banking_agent",  # Add route to non-Maben banking agent
        "terminal_error_response": END
    }
)

# Conditional edges for agent nodes
workflow.add_conditional_edges(
    "greeting_agent",
    lambda state: state["decision"],
    {
        "conversation_complete": END,
        "terminal_error_response": END
    }
)

workflow.add_conditional_edges(
    "policy_inquiry_agent",
    lambda state: state["decision"],
    {
        "conversation_complete": END,
        "terminal_error_response": END
    }
)

workflow.add_conditional_edges(
    "account_details_agent",
    lambda state: state["decision"],
    {
        "conversation_complete": END,
        "terminal_error_response": END
    }
)


# Conditional edges for non-Maben banking agent
workflow.add_conditional_edges(
    "non_maben_banking_agent",
    lambda state: state["decision"],
    {
        "conversation_complete": END,
        "terminal_error_response": END
    }
)

# Define regular edges for explicit termination paths
logger.info("Defining regular edges for explicit termination paths.")
workflow.add_edge("farewell_agent", END)
workflow.add_edge("transfer_to_human_agent", END)

# Compile the graph
logger.info("Compiling the LangGraph application...")
app_graph = workflow.compile()
logger.info("LangGraph workflow compiled successfully.")

# Optional: Add a function to visualize the graph structure
def print_graph_structure():
    """Print the graph structure for debugging purposes."""
    logger.info("=== LangGraph Workflow Structure ===")
    logger.info("Entry Point: fetch_user_and_deposit_data")
    logger.info("Nodes: fetch_user_and_deposit_data, detect_intent, greeting_agent, policy_inquiry_agent, account_details_agent, sd_opening_agent, farewell_agent, transfer_to_human_agent, non_maben_banking_agent")
    logger.info("Flow: fetch_user_and_deposit_data -> detect_intent -> [specific_agent] -> END")
    logger.info("=====================================")

if __name__ == "__main__":
    print_graph_structure()