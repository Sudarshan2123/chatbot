import os
import yaml
import logging
from pathlib import Path
from typing import Any, Optional

from google.oauth2 import service_account


logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

CONFIG_FILE_NAME = "config.yaml"
CONFIG: dict[str, Any] = {}
GCP_CREDENTIALS_OBJ: Optional[service_account.Credentials] = None   


current_file = Path(__file__).resolve()
current_dir = current_file.parent

possible_paths = [
    current_dir / CONFIG_FILE_NAME,
    current_dir.parent / "config" / CONFIG_FILE_NAME,
    current_dir.parent / CONFIG_FILE_NAME,
]

config_path: Path | None = None
for path in possible_paths:
    if path.exists():
        config_path = path
        break

if config_path:
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            CONFIG = yaml.safe_load(f) or {}
        logger.info(f"Configuration loaded from {config_path}")
    except yaml.YAMLError as e:
        logger.critical(f"YAML parse error in {config_path}: {e}", exc_info=True)
        CONFIG = {}
    except Exception as e:
        logger.critical(f"Failed to read {config_path}: {e}", exc_info=True)
        CONFIG = {}
else:
    logger.warning("config.yaml not found in any expected location. Using environment variables.")
    CONFIG = {}




def _load_gcp_credentials_from_config() -> Optional[service_account.Credentials]:
    """Create a Credentials object from the GCP_CREDENTIALS dict in config.yaml."""
    gcp_dict = CONFIG.get("GCP_CREDENTIALS")
    if not gcp_dict:
        logger.warning("GCP_CREDENTIALS not found in config.yaml – falling back to ADC.")
        return None

    try:
        creds = service_account.Credentials.from_service_account_info(gcp_dict)
        logger.info(
            "GCP credentials loaded from config.yaml (project_id=%s)",
            gcp_dict.get("project_id")
        )
        return creds
    except Exception as exc:  
        logger.error("Failed to build GCP credentials from config.yaml", exc_info=exc)
        return None

GCP_CREDENTIALS_OBJ = _load_gcp_credentials_from_config()




def _get(key: str, default: Any = None, env_only: bool = False) -> Any:
    if env_only:
        return os.getenv(key, default)
    return CONFIG.get(key, os.getenv(key, default))



CHROMA_DB_PATH = CONFIG.get("CHROMA_DB_PATH", os.getenv("CHROMA_DB_PATH"))
embedding_model= CONFIG.get("embedding_model", os.getenv("embedding_model"))
CHROMA_COLLECTION_NAME=CONFIG.get("CHROMA_COLLECTION_NAME",os.getenv("CHROMA_COLLECTION_NAME"))
REDIS_URL = CONFIG.get("REDIS_URL", os.getenv("REDIS_URL"))

SPLASH_URL = CONFIG.get("SPLASH_URL", os.getenv("SPLASH_URL"))  
CUSTOMER_SERVICE_URL = CONFIG.get("CUSTOMER_SERVICE_URL", os.getenv("CUSTOMER_SERVICE_URL"))
DEPOSIT_URL = CONFIG.get("DEPOSIT_URL",os.getenv("DEPOSIT_URL"))
PAYMENT_URL = CONFIG.get("PAYMENT_URL", os.getenv("PAYMENT_URL"))
SCHEME_URL = CONFIG.get("SCHEME_URL", os.getenv("SCHEME_URL"))
PSD_URL = CONFIG.get("PSD_URL", os.getenv("PSD_URL"))
BALANCE_URL = CONFIG.get("BALANCE_URL", os.getenv("BALANCE_URL"))
SERVICE_CHARGE_URL = CONFIG.get("SERVICE_CHARGE_URL", os.getenv("SERVICE_CHARGE_URL"))

LLM_MODEL_NAME = CONFIG.get("LLM_MODEL_NAME", os.getenv("LLM_MODEL_NAME"))
LLM_TEMPERATURE = float(CONFIG.get("LLM_TEMPERATURE", os.getenv("LLM_TEMPERATURE", 0.3))) 
MAX_HISTORY_LENGTH = int(CONFIG.get("MAX_HISTORY_LENGTH", os.getenv("MAX_HISTORY_LENGTH"))) 

AES_ENCRYPTION_KEY = CONFIG.get("AES_ENCRYPTION_KEY",os.getenv("AES_ENCRYPTION_KEY"))
SECRET_KEY = CONFIG.get("SECRET_KEY",os.getenv("SECRET_KEY"))
ALGORITHM = CONFIG.get("ALGORITHM",os.getenv("ALGORITHM"))


