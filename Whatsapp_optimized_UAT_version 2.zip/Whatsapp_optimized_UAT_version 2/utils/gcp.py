from google.oauth2 import service_account
from google.auth import default, exceptions as auth_exceptions
from google.cloud import resourcemanager_v3
from typing import Optional
import json
import logging
import time
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 2

def decrypt_data(encrypted_dict: dict, encryption_key_b64: str) -> Optional[str]:
    """
    Decrypts data encrypted with AES-256-GCM.
    
    """
    try:
        aes_key = base64.urlsafe_b64decode(encryption_key_b64)
        if len(aes_key) != 32:
            logging.error(f"AES-256 key must be 32 bytes long. Got {len(aes_key)} bytes.")
            return None
        
        aesgcm = AESGCM(aes_key)
        
        ciphertext = base64.urlsafe_b64decode(encrypted_dict["encrypted_data"])
        nonce = base64.urlsafe_b64decode(encrypted_dict["iv"])
        tag = base64.urlsafe_b64decode(encrypted_dict["tag"])
        
        encrypted_data_with_tag = ciphertext + tag
        
        aad = b""
        decrypted_data = aesgcm.decrypt(nonce, encrypted_data_with_tag, aad)
        
        return decrypted_data.decode('utf-8')
    
    except InvalidTag:
        logging.error("Decryption failed: Invalid authentication tag. Data may be corrupted or key is incorrect.")
        return None
    except Exception as e:
        logging.error(f"Error decrypting data: {e}", exc_info=True)
        return None


def load_gcp_credentials() -> Optional[service_account.Credentials]:
    """Loads and authenticates GCP credentials automatically or from environment variables."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            credentials, project_id = default()
            if credentials and project_id:
                try:
                    project_client = resourcemanager_v3.ProjectsClient(credentials=credentials)
                    request = resourcemanager_v3.GetProjectRequest(name=f"projects/{project_id}")
                    project_info = project_client.get_project(request=request)
                    logging.info(f"Attempt {attempt}: GCP default credentials loaded and project '{project_info.project_id}' obtained.")
                    return credentials
                except auth_exceptions.GoogleAuthError as auth_error:
                    logging.error(f"Attempt {attempt}: Authentication error with default credentials: {auth_error}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                except Exception as e:
                    logging.error(f"Attempt {attempt}: Error fetching project info with default credentials: {e}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                return credentials

            if "GOOGLE_APPLICATION_CREDENTIALS_ENCRYPTED" in os.environ:
                try:
                    encrypted_file_path = os.environ["GOOGLE_APPLICATION_CREDENTIALS_ENCRYPTED"]
                    encryption_key = os.environ.get("AES_ENCRYPTION_KEY")
                    
                    if not encryption_key:
                        logging.error(f"Attempt {attempt}: AES_ENCRYPTION_KEY not found in environment.")
                        if attempt == MAX_RETRIES:
                            return None
                        time.sleep(RETRY_DELAY_SECONDS)
                        continue
                    
                    with open(encrypted_file_path, 'r') as f:
                        encrypted_dict = json.load(f)
                    
                    decrypted_content = decrypt_data(encrypted_dict, encryption_key)
                    
                    if not decrypted_content:
                        logging.error(f"Attempt {attempt}: Failed to decrypt credentials.")
                        if attempt == MAX_RETRIES:
                            return None
                        time.sleep(RETRY_DELAY_SECONDS)
                        continue
                    
                    creds_info = json.loads(decrypted_content)
                    credentials = service_account.Credentials.from_service_account_info(creds_info)
                    logging.info(f"Attempt {attempt}: GCP credentials loaded from encrypted file.")
                    return credentials
                    
                except FileNotFoundError:
                    logging.error(f"Attempt {attempt}: Encrypted credentials file not found: {os.environ.get('GOOGLE_APPLICATION_CREDENTIALS_ENCRYPTED')}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                except json.JSONDecodeError as e:
                    logging.error(f"Attempt {attempt}: Error decoding encrypted credentials: {e}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                except Exception as e:
                    logging.error(f"Attempt {attempt}: Error loading encrypted credentials: {e}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)

            if "GOOGLE_APPLICATION_CREDENTIALS_CONTENT" in os.environ:
                try:
                    creds_info = json.loads(os.environ["GOOGLE_APPLICATION_CREDENTIALS_CONTENT"])
                    credentials = service_account.Credentials.from_service_account_info(creds_info)
                    logging.info(f"Attempt {attempt}: GCP credentials loaded from GOOGLE_APPLICATION_CREDENTIALS_CONTENT.")
                    return credentials
                except json.JSONDecodeError:
                    logging.error(f"Attempt {attempt}: Error decoding GOOGLE_APPLICATION_CREDENTIALS_CONTENT.")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                except Exception as e:
                    logging.error(f"Attempt {attempt}: Error creating credentials from content: {e}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                    
            elif "GOOGLE_APPLICATION_CREDENTIALS" in os.environ:
                try:
                    credentials = service_account.Credentials.from_service_account_file(
                        os.environ["GOOGLE_APPLICATION_CREDENTIALS"]
                    )
                    logging.info(f"Attempt {attempt}: GCP credentials loaded from GOOGLE_APPLICATION_CREDENTIALS file.")
                    return credentials
                except FileNotFoundError:
                    logging.error(f"Attempt {attempt}: Service account key file not found: {os.environ['GOOGLE_APPLICATION_CREDENTIALS']}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
                except Exception as e:
                    logging.error(f"Attempt {attempt}: Error creating credentials from file: {e}")
                    if attempt == MAX_RETRIES:
                        return None
                    time.sleep(RETRY_DELAY_SECONDS)
            else:
                logging.warning(f"Attempt {attempt}: Neither default credentials nor environment variables found.")
                if attempt == MAX_RETRIES:
                    return None
                time.sleep(RETRY_DELAY_SECONDS)

        except Exception as e:
            logging.error(f"Attempt {attempt}: Unexpected error loading GCP credentials: {e}")
            if attempt == MAX_RETRIES:
                return None
            time.sleep(RETRY_DELAY_SECONDS)

    logging.error("ERROR: Failed to load and validate GCP credentials after multiple retries.")
    return None