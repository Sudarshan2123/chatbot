import os
import logging
import redis.asyncio as redis
from typing import Optional, List
from src.config import REDIS_URL

logger = logging.getLogger(__name__)

class RedisCache:
    """
    A class to manage Redis caching operations.
    Encapsulates the Redis client and provides methods for getting, setting,
    deleting data, and scanning/deleting keys by pattern from the cache.
    """
    def __init__(self):
        self._redis_client: Optional[redis.Redis] = None
        self.REDIS_URL = REDIS_URL
        self.DEFAULT_CACHE_EXPIRATION_SECONDS = 1800

        if not self.REDIS_URL:
            logger.error("REDIS_URL not set in environment variables. Redis caching will not be available.")
        else:
            try:
                self._redis_client = redis.from_url(self.REDIS_URL, decode_responses=True)
                logger.info(f"Connected to Redis at {self.REDIS_URL}")
            except Exception as e:
                logger.error(f"Failed to connect to Redis at {self.REDIS_URL}: {e}")
                self._redis_client = None

    async def get(self, key: str) -> Optional[str]:
        """
        Retrieves data from Redis cache.

        """
        if not self._redis_client:
            logger.debug(f"Redis client not initialized, skipping cache read for key: {key}.")
            return None
        try:
            data = await self._redis_client.get(key)
            if data:
                logger.debug(f"Retrieved data for key: {key} from Redis cache.")
            return data
        except Exception as e:
            logger.error(f"Error retrieving data for key {key} from Redis: {e}", exc_info=True)
            return None

    async def set_to_cache(self, key: str, value: str, expiration_seconds: Optional[int] = None) -> None:
        """
        Stores data in Redis cache with an optional expiration time.

        """
        if not self._redis_client:
            logger.debug(f"Redis client not initialized, skipping cache write for key: {key}.")
            return
        
        ex = expiration_seconds if expiration_seconds is not None else self.DEFAULT_CACHE_EXPIRATION_SECONDS
        try:    
            await self._redis_client.set(key, value, ex=ex)
            logger.debug(f"Cached data for key: {key} in Redis with expiration {ex}s.")
        except Exception as e:
            logger.error(f"Error caching data for key {key} in Redis: {e}", exc_info=True)

    async def delete_from_cache(self, key: str) -> None:
        """
        Deletes data from Redis cache.

        """
        if not self._redis_client:
            logger.debug(f"Redis client not initialized, skipping cache delete for key: {key}.")
            return
        try:
            deleted_count = await self._redis_client.delete(key)
            if deleted_count > 0:
                logger.debug(f"Deleted data for key: {key} from Redis cache.")
            else:
                logger.debug(f"Key: {key} not found in Redis cache to delete.")
        except Exception as e:
            logger.error(f"Error deleting data for key {key} from Redis: {e}", exc_info=True)

    async def scan_keys_by_pattern(self, pattern: str) -> List[str]:
        """
        Scans Redis keys matching a given pattern efficiently.

        """
        if not self._redis_client:
            logger.debug("Redis client not initialized, skipping key scan.")
            return []
        
        keys = []
        cursor = '0'
        try:
            while cursor != 0:
                cursor, scan_keys = await self._redis_client.scan(cursor, match=pattern)
                keys.extend(scan_keys)
            logger.debug(f"Scanned {len(keys)} keys matching pattern: {pattern}")
            return keys
        except Exception as e:
            logger.error(f"Error scanning keys with pattern {pattern} from Redis: {e}", exc_info=True)
            return []

    async def delete_keys_by_pattern(self, pattern: str) -> int:
        """
        Deletes all Redis keys matching a given pattern.

        """
        if not self._redis_client:
            logger.debug("Redis client not initialized, skipping patterned key deletion.")
            return 0
        
        try:
            keys_to_delete = await self.scan_keys_by_pattern(pattern)
            if keys_to_delete:
                deleted_count = await self._redis_client.delete(*keys_to_delete)
                logger.info(f"Deleted {deleted_count} keys matching pattern: {pattern}.")
                return deleted_count
            else:
                logger.debug(f"No keys found matching pattern {pattern} to delete.")
                return 0
        except Exception as e:
            logger.error(f"Error deleting keys with pattern {pattern} from Redis: {e}", exc_info=True)
            return 0

    async def expire_key(self, key: str, seconds: int) -> None:
        """
        Sets or updates the expiration time (TTL) for a specific key in Redis.

        """
        if not self._redis_client:
            logger.debug(f"Redis client not initialized, skipping expire for key: {key}.")
            return
        try:
            await self._redis_client.expire(key, seconds)
            logger.debug(f"Set/updated TTL for key {key} to {seconds}s.")
        except Exception as e:
            logger.error(f"Error setting TTL for key {key} in Redis: {e}", exc_info=True)

    async def close(self):
        """
        Closes the Redis connection pool.
        This should be called during application shutdown.
        """
        if self._redis_client: # Just check if the client itself exists
            await self._redis_client.close() # Directly call close on the client instance
            logger.info("Redis connection closed.")
        else:
            logger.debug("Redis client not initialized, no connection to close.")

