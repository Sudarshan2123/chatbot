import os
import re
import json
import logging
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

import aiohttp
import jwt
from dotenv import load_dotenv

from langchain_google_vertexai import ChatVertexAI
from langgraph.graph import END

from utils.api_to_redis import (
    UserProfileManager,
    user_profile_manager,
    redis_cache_instance,
)
from utils.ChatHistoryManager import ChatHistoryManager
from src.config import LLM_MODEL_NAME, LLM_TEMPERATURE, SECRET_KEY,ALGORITHM,SCHEME_URL,PAYMENT_URL,GCP_CREDENTIALS_OBJ
from utils.TokenGeneration import TokenManagement


################################################################ Logging Setup ####################################################################

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

######################################################################################################################################

try:
    llm_instance = ChatVertexAI(
        model=LLM_MODEL_NAME,
        temperature=LLM_TEMPERATURE,
        credentials=GCP_CREDENTIALS_OBJ,
        max_output_tokens=1024,
        max_retries=2
    )
    logger.info(f"LLM initialized: {llm_instance.model_name}")
except Exception as exc:  
    logger.critical("Failed to init ChatVertexAI", exc_info=exc)
    llm_instance = None

##########################################################################################################################################

chat_history_manager = ChatHistoryManager(redis_cache_instance)

token_manager = TokenManagement()

###############################################################################################################################################

class TokenHelper:
    """JWT token validation and test token creation."""
    __slots__ = ('secret', 'algorithm')

    def __init__(self) -> None:
        self.secret = SECRET_KEY
        self.algorithm = ALGORITHM

    def validate(self, stored_token: str) -> Optional[str]:
        """Return phone number if valid, else None."""
        try:
            payload = jwt.decode(stored_token, self.secret, algorithms=[self.algorithm])
            phone = payload.get("user_id")
            if not phone:
                logger.error("Token missing user_id")
                return None

            exp = payload.get("exp")
            if exp:
                left = datetime.fromtimestamp(exp, tz=timezone.utc) - datetime.now(timezone.utc)
                if left.total_seconds() < 600:
                    logger.warning(f"Token expires in {left} for {phone}")

            logger.info(f"Token valid: {phone}")
            return phone
        except jwt.ExpiredSignatureError:
            logger.error("Token expired")
        except jwt.InvalidTokenError as e:
            logger.error(f"Invalid token: {e}")
        except Exception as e:  
            logger.error(f"Token error: {e}", exc_info=True)
        return None

    def create_test_token(self, phone_number: str) -> str:
        """Generate test JWT."""
        return token_manager.token_creation(phone_number)

################################################################################################################################

    
class Confirmation:
    @staticmethod
    def is_confirmation(user_input: str) -> bool:
        words = ["yes", "confirm", "ok", "okay", "proceed", "sure", "correct", "agree"]
        return any(w in user_input.lower() for w in words)

################################################################################################################################

class Cancellation:
    @staticmethod
    def is_cancellation(user_input: str) -> bool:
        words = ["no", "cancel", "back", "stop", "nevermind", "exit"]
        return any(w in user_input.lower() for w in words)

################################################################################################################################

class NonBanking:
    @staticmethod
    def is_non_maben_banking_query(query: str) -> bool:
        banks = [
            'sbi', 'state bank of india', 'hdfc', 'icici', 'axis bank', 'kotak',
            'punjab national bank', 'pnb', 'canara bank', 'union bank', 'bob',
            'bank of baroda', 'indian bank', 'central bank', 'yes bank',
            'idfc first bank', 'rbl bank', 'bandhan bank', 'karur vysya bank',
            'south indian bank', 'federal bank', 'city union bank',
            'other bank', 'different bank', 'another bank'
        ]
        return any(b in query.lower() for b in banks)

################################################################################################################################

class PolicyQuery:

    @staticmethod
    def is_policy_related_query(query: str) -> bool:
        personal = [
            'my pan', 'my pancard', 'my account number', 'my balance', 'my name',
            'my phone', 'my deposits', 'my deposit details', 'my customer id',
            'what is my', 'show my', 'tell me my', 'my profile', 'my information'
        ]
        if any(p in query.lower() for p in personal):
            return False

        policy = [
            'policy', 'policies', 'terms and conditions', 'rules', 'regulations',
            'eligibility criteria', 'requirements', 'procedure', 'process',
            'documentation required', 'penalty charges', 'withdrawal rules',
            'premature closure charges', 'minimum amount required',
            'maximum amount allowed', 'tenure options', 'deposit scheme features',
            'rd scheme details', 'fd scheme details', 'how to open',
            'what documents needed', 'explain the process', 'information about scheme',
            'details about policy', 'general information', 'what are the',
            'how does', 'what happens if', 'charges applicable'
        ]
        return any(p in query.lower() for p in policy)

###############################################################################################################################

class FormatHelper:
    """Currency, date, amount, and summary formatting."""

    @staticmethod
    def currency(amount: float) -> str:
        return f"₹{amount:,.2f}"
    
    @staticmethod
    def format_date(date_str: str) -> str: 
        try:
            if "T" in date_str:
                dt = datetime.fromisoformat(date_str.replace("T", " ").replace("Z", ""))
            else:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
            return dt.strftime("%d %B %Y")
        except Exception:
            return date_str

    @staticmethod
    def date(date_str: str) -> str:
        try:
            if "T" in date_str:
                dt = datetime.fromisoformat(date_str.replace("T", " ").replace("Z", ""))
            else:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
            return dt.strftime("%d %B %Y")
        except Exception:
            return date_str

    @staticmethod
    def extract_amount(message: str) -> Optional[float]:
        patterns = [
            r'₹(\d+(?:\.\d+)?)',
            r'(\d+(?:\.\d+)?)\s*rupees',
            r'deposit\s+(\d+(?:\.\d+)?)',
            r'open\s+with\s+(\d+(?:\.\d+)?)',
            r'amount\s+(\d+(?:\.\d+)?)',
            r'(\d+(?:\.\d+)?)',
        ]
        for p in patterns:
            m = re.search(p, message, re.IGNORECASE)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    continue
        return None
############################################################################################################################

class Calculate:
    @staticmethod
    def calculate_total_investment(deposits: List[Dict]) -> float:
        return sum(d.get("depositamount", 0) for d in deposits)

    @staticmethod
    def calculate_total_maturity(deposits: List[Dict]) -> float:
        return sum(d.get("maturityAmount", 0) for d in deposits)

########################################################################################################################################################

class DepositHelper:

    @staticmethod
    def get_deposit_summary(deposits: List[Dict]) -> Dict[str, Any]:
        if not deposits:
            return {}

        total_inv = Calculate.calculate_total_investment(deposits)
        total_mat = Calculate.calculate_total_maturity(deposits)
        types: Dict[str, Dict[str, Any]] = {}
        for d in deposits:
            typ = d.get("deposittype", "Unknown")
            types.setdefault(typ, {"count": 0, "amount": 0})
            types[typ]["count"] += 1
            types[typ]["amount"] += d.get("depositamount", 0)

        return {
            "total_investment": total_inv,
            "total_maturity": total_mat,
            "total_deposits": len(deposits),
            "deposit_types": types,
            "expected_returns": total_mat - total_inv,
        }

#################################################################################################################################

class ExtractCustomerId:
    @staticmethod
    def extract_customer_id(profile_data: Optional[Dict[str, Any]]) -> Optional[str]:
        if not profile_data or not isinstance(profile_data, dict):
            return None
        customers = profile_data.get("customers", [])
        if isinstance(customers, list) and customers:
            first = customers[0]
            return first.get("customerId") or first.get("customerid") or first.get("CustomerId")
        return (
            profile_data.get("customerId")
            or profile_data.get("customerid")
            or profile_data.get("CustomerId")
        )

###########################################################################################################################3


class SDHelper:
    """SD-specific API calls."""

    def __init__(self) -> None:
        self.scheme_url = SCHEME_URL
        self.payment_url = PAYMENT_URL

    @staticmethod
    def detect_product_selection(user_input: str) -> Optional[str]:
        """Detect product from input (supports 1-6 or keywords)."""
        lower = user_input.lower().strip()

        if lower in ("1", "2", "3", "4", "5", "6"):
            return {
                "1": "savings_deposit",
                "2": "fixed_deposit",
                "3": "recurring_deposit",
                "4": "gold_loan",
                "5": "lap",
                "6": "add_bank",
            }[lower]

        mapping = {
            "savings_deposit": ["savings deposit", "sd", "savings account", "save money"],
            "fixed_deposit": ["fixed deposit", "fd", "fixed", "term deposit"],
            "recurring_deposit": ["recurring deposit", "rd", "recurring", "monthly deposit"],
            "gold_loan": ["gold loan", "gold", "loan against gold"],
            "lap": ["l.a.p", "lap", "loan against property", "property loan"],
            "add_bank": ["add bank", "link bank", "bank account", "add account"],
        }
        for product, keywords in mapping.items():
            if any(k in lower for k in keywords):
                return product
        return None

    @staticmethod
    def detect_sd_operation(user_input: str) -> Optional[str]:
        """Detect SD operation (open, withdraw, etc.)."""
        lower = user_input.lower().strip()
        ops = {
            "open": ["open", "e-saving deposit open", "e-saving", "new account", "create", "start", "open sd"],
            "withdrawal": ["withdrawal", "withdraw", "take out money"],
            "remittance": ["remittance", "remit", "send money"],
            "fund_transfer_other": ["fund transfer others", "transfer to other bank", "external transfer", "other bank"],
            "fund_transfer_maben": ["fund transfer maben", "transfer within maben", "internal transfer", "within maben"],
            "add_beneficiary": ["add beneficiary", "add manage beneficiary", "new beneficiary", "manage beneficiary"],
        }
        for op, kws in ops.items():
            if any(k in lower for k in kws):
                logger.info(f"SD operation: '{op}' → '{user_input}'")
                return op
        logger.warning(f"No SD operation: '{user_input}'")
        return None

    async def fetch_sd_scheme_details(self, session_id: str) -> Optional[dict]:
        try:
            async with aiohttp.ClientSession() as sess:
                async with sess.get(self.scheme_url, params={"session_id": session_id}) as resp:
                    return await resp.json() if resp.status == 200 else None
        except Exception as e:  
            logger.error(f"SD scheme error: {e}", exc_info=True)
            return None

    async def fetch_sd_schemes(self, phone_number: str, jwt_token: str) -> List[dict]:
        headers = {
            "Authorization": f"Bearer {jwt_token}",
            "Content-Type": "application/json",
        }
        async with aiohttp.ClientSession() as sess:
            try:
                async with sess.get(self.scheme_url, headers=headers) as resp:
                    if resp.status != 200:
                        logger.error(f"API {resp.status}: {await resp.text()}")
                        return []
                    data = await resp.json()
                    raw = data.get("eligibleSchemes", [])
                    formatted = [
                        {
                            "id": s.get("schemeId", s.get("id", "")),
                            "name": s.get("schemeName", s.get("name", "")),
                            "min_amount": s.get("minAmount", s.get("min_amount", 0)),
                        }
                        for s in raw
                    ]
                    logger.info(f"Fetched {len(formatted)} schemes for {phone_number}")
                    return formatted
            except Exception as e:  
                logger.error(f"Scheme fetch error: {e}", exc_info=True)
                return []

################################################################################################################################

class LLMHelper:
    """Access to Vertex AI LLM."""
    @property
    def llm(self):
        if llm_instance is None:
            raise RuntimeError("LLM not initialized. Check GCP credentials.")
        return llm_instance

####################################################################################################################################

class History:
    @property
    def history(self) -> ChatHistoryManager:
        return chat_history_manager

#####################################################################################################################################

class UserProfileManagerHelper:
    @property
    def profile(self) -> UserProfileManager:
        return user_profile_manager


token_helper = TokenHelper()
confirmation_helper = Confirmation()
cancellation_helper = Cancellation()
non_banking_helper = NonBanking()
policy_query_helper = PolicyQuery()
format_helper = FormatHelper()
calculate_helper = Calculate()
deposit_helper = DepositHelper()
extract_customer_id_helper = ExtractCustomerId()
sd_helper = SDHelper()
llm_helper = LLMHelper()
chat_history_helper = History()
user_profile_helper = UserProfileManagerHelper()

__all__ = [
    "token_helper",
    "confirmation_helper",
    "cancellation_helper",
    "non_banking_helper",
    "policy_query_helper",
    "format_helper",
    "calculate_helper",
    "deposit_helper",
    "extract_customer_id_helper",
    "sd_helper",
    "llm_helper",
    "open_sd_helper", 
    "chat_history_helper", 
    "user_profile_helper" 
]