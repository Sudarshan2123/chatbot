import asyncio
import json
import hashlib
from datetime import datetime
from typing import Optional, Dict, Any
import logging
import time
from dotenv import load_dotenv
from utils.redis_cache import RedisCache
from src.config import SPLASH_URL, CUSTOMER_SERVICE_URL, DEPOSIT_URL,CONFIG
from utils.HashingApi import CustomerserviceHash, DepositHash, SplashHashing
from src.classes import UserProfileError,DepositError,Customer
load_dotenv()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)



class SecurityMetrics:
    """Track security-related metrics for monitoring"""
    
    __slots__ = (
        'CUSTOMER_SERVICE_URL',
        'SPLASH_URL',
        'api_call_failures',
        'authentication_failures',
        'suspicious_patterns'
    )

    def __init__(self):
        self.CUSTOMER_SERVICE_URL = CUSTOMER_SERVICE_URL
        self.SPLASH_URL = SPLASH_URL
        self.api_call_failures = {}  
        self.authentication_failures = {}  
        self.suspicious_patterns = {}  
        
    def record_api_failure(self, phone_number: str, error_type: str):
        """Record API call failures for monitoring"""
        if phone_number not in self.api_call_failures:
            self.api_call_failures[phone_number] = {}
        
        if error_type not in self.api_call_failures[phone_number]:
            self.api_call_failures[phone_number][error_type] = 0
        
        self.api_call_failures[phone_number][error_type] += 1
        
        total_failures = sum(self.api_call_failures[phone_number].values())
        if total_failures > 5:  
            logger.warning(f"High failure count detected for phone number: {phone_number[:4]}****")
    
    def record_auth_failure(self, phone_number: str):
        """Record authentication failures"""
        if phone_number not in self.authentication_failures:
            self.authentication_failures[phone_number] = []
        
        self.authentication_failures[phone_number].append(time.time())
        
        cutoff_time = time.time() - 1800
        self.authentication_failures[phone_number] = [
            ts for ts in self.authentication_failures[phone_number] 
            if ts > cutoff_time
        ]
    
    def is_suspicious_activity(self, phone_number: str) -> bool:
        """Check if there's suspicious activity for a phone number"""
        if phone_number in self.authentication_failures:
            recent_failures = len(self.authentication_failures[phone_number])
            if recent_failures > 3: 
                return True
        
        if phone_number in self.api_call_failures:
            total_failures = sum(self.api_call_failures[phone_number].values())
            if total_failures > 10:  
                return True
        
        return False

security_metrics = SecurityMetrics()

class APIRedisCache:
    __slots__ = ('redis_cache',)
    def __init__(self, redis_cache_instance: RedisCache):
        self.redis_cache = redis_cache_instance
        logger.info("APIRedisCache initialized with RedisCache instance.")
    
    def generate_cache_key(self, phone_number: str, api_type: str = "user_profile") -> str:
        """Generate cache key for phone number based profile data with enhanced security"""
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        cache_string = f"{api_type}:{phone_number}"
        cache_key = f"api_cache:{api_type}:{hashlib.md5(cache_string.encode()).hexdigest()}"
        logger.debug(f"Generated cache key for phone {masked_phone} and type {api_type}")
        return cache_key
    
    async def get_from_cache(self, cache_key: str) -> Optional[Dict]:
        try:
            cached_data = await self.redis_cache.get(cache_key)
            if cached_data:
                return json.loads(cached_data)
            return None
        except Exception as e:
            logger.error(f"Error retrieving from cache for key {cache_key[:20]}...: {e}", exc_info=True)
            return None
    
    async def store_in_cache(self, cache_key: str, data: Any, ttl: int = 1800, metadata: Optional[Dict] = None) -> bool:
        try:
            enhanced_metadata = metadata or {}
            enhanced_metadata.update({
                'cached_at': datetime.now().isoformat(),
                'ttl': ttl,
                'security_version': '1.0'
            })
            
            cache_data = {
                'data': data,
                'metadata': enhanced_metadata
            }
            await self.redis_cache.set_to_cache(cache_key, json.dumps(cache_data), expiration_seconds=ttl)
            logger.debug(f"Data stored in cache with enhanced security, TTL: {ttl}s.")
            return True
        except Exception as e:
            logger.error(f"Error storing in cache for key {cache_key[:20]}...: {e}", exc_info=True)
            return False

    async def clear_cache(self, pattern: str = "api_cache:*") -> Dict:
        try:
            deleted_count = await self.redis_cache.delete_keys_by_pattern(pattern) 
            
            if deleted_count > 0:
                logger.info(f"Deleted {deleted_count} cache entries for pattern: {pattern}.")
                return {
                    'success': True,
                    'deleted_count': deleted_count,
                    'pattern': pattern
                }
            else:
                return {
                    'success': True,
                    'deleted_count': 0,
                    'pattern': pattern,
                    'message': 'No keys found matching pattern.'
                }
        except Exception as e:
            logger.error(f"Error clearing cache for pattern {pattern}: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'pattern': pattern
            }

class UserProfileManager:
    """
    Manages fetching and caching user profile data with enhanced security features.
    """
    __slots__ = (
        'cache',
        'CUSTOMER_SERVICE_URL',
        'SPLASH_URL',
        'customer_service_handler',
        'splash_handler',
        'profile_cache_ttl'
    )

    def __init__(self,api_redis_cache: APIRedisCache):
        self.cache = api_redis_cache
        self.CUSTOMER_SERVICE_URL = CUSTOMER_SERVICE_URL
        self.SPLASH_URL = SPLASH_URL
        self.customer_service_handler = CustomerserviceHash()
        self.splash_handler = SplashHashing()
        self.profile_cache_ttl = 1800 
        logger.info("UserProfileManager initialized with enhanced security features.")

    async def get_user_profile_by_phone(self, phone_number: str, jwt_token: str = None) -> Dict[str, Any]:
        """
        Fetches the complete customer data with enhanced security validation
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Attempting secure profile fetch for phone: {masked_phone}")
        
        if security_metrics.is_suspicious_activity(phone_number):
            logger.warning(f"Suspicious activity detected for phone: {masked_phone}")
            raise UserProfileError("Access temporarily restricted due to security concerns.", status_code=403)
        
        cache_key = self.cache.generate_cache_key(phone_number, "user_profile")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            logger.info(f"Profile data for phone {masked_phone} retrieved from secure cache.")
            return cached_data['data']
        
        logger.info(f"No cached data found. Initiating secure API fetch for phone: {masked_phone}")
        
        try:
            if not jwt_token:
                logger.info(f"Performing secure authentication for phone: {masked_phone}")
                splash_data = {
                    "Applicationnumber": "1234",
                    "DeviceID": phone_number
                }
                
                try:
                    splash_success = await self.splash_handler.send_request(
                        url=self.SPLASH_URL,
                        splash_data=splash_data,
                        phone_number=phone_number
                    )
                    
                    if not splash_success or not self.splash_handler.verified_jwt_token:
                        security_metrics.record_auth_failure(phone_number)
                        raise UserProfileError("Authentication failed. Please verify your credentials.", status_code=401)
                    
                    jwt_token = self.splash_handler.verified_jwt_token
                    logger.info(f"Secure authentication successful for phone: {masked_phone}")
                    
                except Exception as auth_error:
                    security_metrics.record_auth_failure(phone_number)
                    security_metrics.record_api_failure(phone_number, "splash_auth")
                    logger.error(f"Authentication error for phone {masked_phone}: {auth_error}")
                    raise UserProfileError("Authentication service temporarily unavailable.", status_code=503)
            
            customer_data_request = {
                "phonenumber": phone_number
            }
            
            try:
                api_response_data = await self.customer_service_handler.send_request(
                    url=self.CUSTOMER_SERVICE_URL,
                    customer_data=customer_data_request,
                    phone_number=phone_number,
                    jwt_token=jwt_token
                )
                
                if not api_response_data or not self.customer_service_handler.last_call_successful:
                    security_metrics.record_api_failure(phone_number, "customer_service")
                    raise UserProfileError("Customer information not accessible at this time.", status_code=404)
                
                logger.info(f"Profile data successfully fetched from secure API for phone: {masked_phone}")
                
                processed_data = self._validate_and_process_response(api_response_data, phone_number)
                
                if not processed_data or processed_data.get('status') != 'Success':
                    security_metrics.record_api_failure(phone_number, "invalid_response")
                    raise UserProfileError("Invalid response received from service.", status_code=500)

                customers = processed_data.get('customers', [])
                if not customers:
                    raise UserProfileError("Customer information not found.", status_code=404)
                
                metadata = {
                    'phone_hash': hashlib.sha256(phone_number.encode()).hexdigest()[:8],  
                    'fetched_at': datetime.now().isoformat(),
                    'source': 'customer_service_api',
                    'customer_count': len(customers),
                    'security_validated': True
                }
                
                await self.cache.store_in_cache(
                    cache_key=cache_key,
                    data=processed_data,
                    ttl=self.profile_cache_ttl,
                    metadata=metadata
                )
                
                logger.info(f"Profile data securely cached for phone: {masked_phone}")
                return processed_data
                
            except Exception as api_error:
                security_metrics.record_api_failure(phone_number, "customer_api")
                logger.error(f"Customer service API error for phone {masked_phone}: {api_error}")
                raise UserProfileError("Service temporarily unavailable. Please try again later.", status_code=503)
                
        except UserProfileError:
            raise
        except Exception as e:
            security_metrics.record_api_failure(phone_number, "unexpected")
            logger.error(f"Unexpected error in secure profile fetch for phone {masked_phone}: {e}", exc_info=True)
            raise UserProfileError("An unexpected error occurred. Please try again later.", status_code=500)

    def _validate_and_process_response(self, api_response_data: Any, phone_number: str) -> Dict[str, Any]:
        """Enhanced response validation with security checks"""
        try:
            if not isinstance(api_response_data, dict):
                logger.warning(f"Invalid response format received for phone: {phone_number[:4]}****")
                return None
            
            if 'status' in api_response_data and 'customers' in api_response_data:
                processed_data = api_response_data
            elif 'customerId' in api_response_data:
                processed_data = {
                    'status': 'Success',
                    'customers': [api_response_data]
                }
            else:
                if 'Data' in api_response_data:
                    data_section = api_response_data['Data']
                    if isinstance(data_section, dict) and 'customers' in data_section:
                        processed_data = {
                            'status': data_section.get('status', 'Success'),
                            'customers': data_section['customers']
                        }
                    else:
                        logger.warning(f"Unexpected data structure in API response for phone: {phone_number[:4]}****")
                        return None
                else:
                    logger.warning(f"Unrecognized response format for phone: {phone_number[:4]}****")
                    return None
            
            customers = processed_data.get('customers', [])
            for customer in customers:
                if not self._validate_customer_data(customer):
                    logger.warning(f"Invalid customer data detected for phone: {phone_number[:4]}****")
                    return None
            
            return processed_data
            
        except Exception as e:
            logger.error(f"Response validation error for phone {phone_number[:4]}****: {e}")
            return None
    
    def _validate_customer_data(self, customer_data: Dict[str, Any]) -> bool:
        """Validate customer data integrity - flexible for API variations"""
        try:
            if not isinstance(customer_data, dict):
                return False
            
            # Validate customer ID (required)
            customer_id = customer_data.get('customerId', '')
            if not isinstance(customer_id, str) or len(customer_id) < 3:
                return False
            
            # Validate customer name (required)
            customer_name = customer_data.get('customerName', '')
            if not isinstance(customer_name, str) or len(customer_name.strip()) < 2:
                return False
            
            # Validate phone number - accept multiple field variations
            # Check for any phone number field (phoneNumber, phoneNumber1, phoneNumber2)
            has_phone = any([
                customer_data.get('phoneNumber'),
                customer_data.get('phoneNumber1'),
                customer_data.get('phoneNumber2')
            ])
            
            if not has_phone:
                logger.debug("No phone number field found in customer data")
                return False
            
            return True
            
        except Exception as e:
            logger.debug(f"Customer data validation exception: {e}")
            return False

    async def cache_user_profile(self, phone_number: str, profile_data: Dict[str, Any]) -> bool:
        """
        Manually cache user profile data with security validation
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Securely caching profile data for phone: {masked_phone}")
        
        if not self._validate_profile_data(profile_data):
            logger.error(f"Invalid profile data provided for caching, phone: {masked_phone}")
            return False
        
        cache_key = self.cache.generate_cache_key(phone_number, "user_profile")
        
        metadata = {
            'phone_hash': hashlib.sha256(phone_number.encode()).hexdigest()[:8],
            'cached_at': datetime.now().isoformat(),
            'source': 'manual_cache',
            'security_validated': True
        }
        
        success = await self.cache.store_in_cache(
            cache_key=cache_key,
            data=profile_data,
            ttl=self.profile_cache_ttl,
            metadata=metadata
        )
        
        if success:
            logger.info(f"Profile data securely cached for phone: {masked_phone}")
        else:
            logger.error(f"Failed to securely cache profile data for phone: {masked_phone}")
            
        return success

    def _validate_profile_data(self, profile_data: Dict[str, Any]) -> bool:
        """Validate profile data structure and content"""
        try:
            if not isinstance(profile_data, dict):
                return False
            
            if 'customers' in profile_data:
                customers = profile_data['customers']
                if not isinstance(customers, list):
                    return False
                
                for customer in customers:
                    if not self._validate_customer_data(customer):
                        return False
            
            return True
            
        except Exception:
            return False

    async def get_cached_user_profile(self, phone_number: str) -> Optional[Dict[str, Any]]:
        """
        Get cached user profile data with security validation
        """
        cache_key = self.cache.generate_cache_key(phone_number, "user_profile")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            if self._validate_cached_data(cached_data):
                masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
                logger.info(f"Valid cached profile data found for phone: {masked_phone}")
                return cached_data['data']
            else:
                await self.clear_user_profile_cache(phone_number)
                logger.warning(f"Invalid cached data removed for security")
                return None
        else:
            return None

    def _validate_cached_data(self, cached_data: Dict[str, Any]) -> bool:
        """Validate cached data integrity and security"""
        try:
            if not isinstance(cached_data, dict):
                return False
            
            if 'data' not in cached_data or 'metadata' not in cached_data:
                return False
            
            data = cached_data['data']
            if not self._validate_profile_data(data):
                return False
            
            metadata = cached_data['metadata']
            if not metadata.get('security_validated', False):
                return False
            
            return True
            
        except Exception:
            return False

    async def clear_user_profile_cache(self, phone_number: str) -> Dict[str, Any]:
        """
        Securely clears the cached profile data for a specific phone number.
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Securely clearing profile cache for phone: {masked_phone}")
        
        cache_key = self.cache.generate_cache_key(phone_number, "user_profile")
        
        try:
            await self.cache.redis_cache.delete_from_cache(cache_key)
            logger.info(f"Profile cache securely cleared for phone: {masked_phone}")
            return {
                'success': True,
                'message': 'Cache cleared successfully',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error securely clearing cache for phone {masked_phone}: {e}", exc_info=True)
            return {
                'success': False,
                'error': 'Cache operation failed',
                'timestamp': datetime.now().isoformat()
            }

    async def get_profile_cache_info(self, phone_number: str) -> Dict[str, Any]:
        """
        Gets cache information with security considerations.
        """
        cache_key = self.cache.generate_cache_key(phone_number, "user_profile")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            metadata = cached_data.get('metadata', {})
            return {
                'cached': True,
                'cached_at': metadata.get('cached_at'),
                'ttl': metadata.get('ttl'),
                'data_available': 'data' in cached_data and cached_data['data'] is not None,
                'security_validated': metadata.get('security_validated', False)
            }
        else:
            return {
                'cached': False,
                'message': 'No cached data found'
            }

    def get_customer_info(self, profile_data: Dict[str, Any], phone_number: str) -> Optional[Customer]:
        """
        Extract customer information with enhanced security validation
        """
        try:
            customers = []
            if 'Data' in profile_data:
                customers = profile_data['Data'].get('customers', [])
            elif 'customers' in profile_data:
                customers = profile_data['customers']
            elif 'customerId' in profile_data:
                customers = [profile_data]
            
            for customer_data in customers:
                # Check all possible phone number fields
                customer_phones = [
                    customer_data.get('phoneNumber'),
                    customer_data.get('phoneNumber1'),
                    customer_data.get('phoneNumber2')
                ]
                
                # Remove None values and check if any match
                customer_phones = [p for p in customer_phones if p]
                
                if phone_number in customer_phones:
                    if self._validate_customer_data(customer_data):
                        try:
                            # Try to create Customer object
                            # If Customer dataclass expects specific fields, map them here
                            return Customer(**customer_data)
                        except TypeError as e:
                            logger.error(f"Customer dataclass instantiation failed: {e}")
                            logger.debug(f"Available fields: {list(customer_data.keys())}")
                            return None
                    else:
                        logger.warning(f"Invalid customer data structure detected")
                        return None
            
            logger.info(f"No matching customer found in validated data")
            return None
            
        except Exception as e:
            masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
            logger.error(f"Error extracting customer info for phone {masked_phone}: {e}")
            return None

    async def refresh_user_profile(self, phone_number: str, jwt_token: str = None) -> Dict[str, Any]:
        """
        Forces a refresh with enhanced security validation
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Force refreshing profile data with security validation for phone: {masked_phone}")
        
        if security_metrics.is_suspicious_activity(phone_number):
            raise UserProfileError("Access temporarily restricted due to security concerns.", status_code=403)
        
        await self.clear_user_profile_cache(phone_number)
        
        return await self.get_user_profile_by_phone(phone_number, jwt_token)

class DepositManager:
    """
    Manages fetching and caching deposit details with enhanced security features.
    """
    __slots__ = (
        'CUSTOMER_SERVICE_URL',
        'SPLASH_URL',
        'deposit_url',
        'cache',
        'deposit_handler',
        'splash_handler',
        'customer_service_handler',
        'deposit_cache_ttl'
    )

    def __init__(self, api_redis_cache: APIRedisCache):
        self.CUSTOMER_SERVICE_URL = CUSTOMER_SERVICE_URL
        self.SPLASH_URL = SPLASH_URL
        self.deposit_url = DEPOSIT_URL
        self.cache = api_redis_cache
        self.deposit_handler = DepositHash()
        self.splash_handler = SplashHashing()
        self.customer_service_handler = CustomerserviceHash()
        self.deposit_cache_ttl = 1800
        logger.info("DepositManager initialized with enhanced security features.")

    async def get_deposit_details_by_phone(self, phone_number: str, jwt_token: str = None, customer_id: str = None) -> Optional[Dict[str, Any]]:
        """
        Fetches deposit details with enhanced security validation
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Attempting secure deposit fetch for phone: {masked_phone}")
        
        if security_metrics.is_suspicious_activity(phone_number):
            logger.warning(f"Suspicious activity detected for deposit fetch, phone: {masked_phone}")
            raise DepositError("Access temporarily restricted due to security concerns.", status_code=403)
        
        cache_key = self.cache.generate_cache_key(phone_number, "deposit_details")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            if self._validate_cached_deposit_data(cached_data):
                logger.info(f"Deposit details for phone {masked_phone} retrieved from secure cache.")
                return cached_data['data']
            else:
                await self.clear_deposit_cache(phone_number)
                logger.warning(f"Invalid cached deposit data removed for security")
        
        logger.info(f"No valid cached deposit data found. Initiating secure API fetch for phone: {masked_phone}")
        
        try:
            if not jwt_token:
                logger.info(f"Performing secure authentication for deposit fetch, phone: {masked_phone}")
                splash_data = {
                    "Applicationnumber": "1234",
                    "DeviceID": phone_number
                }
                
                try:
                    splash_success = await self.splash_handler.send_request(
                        url=self.SPLASH_URL,
                        splash_data=splash_data,
                        phone_number=phone_number
                    )
                    
                    if not splash_success or not self.splash_handler.verified_jwt_token:
                        security_metrics.record_auth_failure(phone_number)
                        raise DepositError("Authentication failed for deposit access.", status_code=401)
                    
                    jwt_token = self.splash_handler.verified_jwt_token
                    logger.info(f"Secure authentication successful for deposit fetch, phone: {masked_phone}")
                    
                except Exception as auth_error:
                    security_metrics.record_auth_failure(phone_number)
                    security_metrics.record_api_failure(phone_number, "splash_auth_deposit")
                    logger.error(f"Deposit authentication error for phone {masked_phone}: {auth_error}")
                    raise DepositError("Authentication service temporarily unavailable.", status_code=503)
            
            if not customer_id:
                logger.info(f"Resolving customer ID for secure deposit fetch")
                
                try:
                    from utils.HashingApi import get_global_customer_id
                    customer_id = get_global_customer_id()
                    if customer_id:
                        logger.info(f"Customer ID retrieved from secure global storage")
                except (ImportError, AttributeError):
                    logger.debug("Global customer ID function not available")
                    customer_id = None
                
                if not customer_id:
                    logger.info(f"Fetching customer ID from secure customer service for phone: {masked_phone}")
                    customer_data_request = {
                        "phonenumber": phone_number
                    }
                    
                    try:
                        customer_response = await self.customer_service_handler.send_request(
                            url=self.CUSTOMER_SERVICE_URL,
                            customer_data=customer_data_request,
                            jwt_token=jwt_token,
                            phone_number=phone_number
                        )
                        
                        if customer_response and self.customer_service_handler.last_call_successful:
                            customer_id = self._extract_customer_id_from_response(customer_response, phone_number)
                            
                            if not customer_id:
                                try:
                                    from utils.HashingApi import get_global_customer_id
                                    customer_id = get_global_customer_id()
                                    if customer_id:
                                        logger.info(f"Customer ID retrieved from global storage after API call")
                                except (ImportError, AttributeError):
                                    pass
                                    
                        else:
                            security_metrics.record_api_failure(phone_number, "customer_service_deposit")
                            raise DepositError("Customer information not accessible for deposit fetch.", status_code=404)
                            
                    except Exception as e:
                        security_metrics.record_api_failure(phone_number, "customer_api_deposit")
                        logger.error(f"Error fetching customer data for deposits, phone {masked_phone}: {e}")
                        raise DepositError("Customer service temporarily unavailable.", status_code=503)
                
                if not customer_id:
                    logger.error(f"Customer ID could not be determined for secure deposit fetch")
                    raise DepositError("Customer identification failed.", status_code=404)
            
            logger.info(f"Using validated customer ID for secure deposit fetch")
            
            logger.info(f"Fetching deposit details with enhanced security")            
            try:
                deposit_details = await self.deposit_handler.send_request(
                    url=self.deposit_url,
                    phone_number=phone_number,
                    jwt_token=jwt_token,
                    custom_customer_id=customer_id
                )
                
                logger.info(f"Deposit API response received for secure session")
                
            except Exception as e:
                security_metrics.record_api_failure(phone_number, "deposit_api")
                logger.error(f"Error calling secure deposit API for phone {masked_phone}: {e}")
                raise DepositError("Deposit service temporarily unavailable.", status_code=503)
            
            if not deposit_details or not self.deposit_handler.last_call_successful:
                logger.info(f"No deposit details returned from secure API")
                empty_response = {
                    "deposits": [],
                    "status": "No deposits found",
                    "customer_id": customer_id
                }
                metadata = {
                    'phone_hash': hashlib.sha256(phone_number.encode()).hexdigest()[:8],
                    'customer_id_hash': hashlib.sha256(customer_id.encode()).hexdigest()[:8],
                    'fetched_at': datetime.now().isoformat(),
                    'source': 'deposit_api',
                    'status': 'no_data',
                    'security_validated': True
                }
                await self.cache.store_in_cache(
                    cache_key=cache_key,
                    data=empty_response,
                    ttl=self.deposit_cache_ttl,
                    metadata=metadata
                )
                return empty_response
            
            normalized_response = self._normalize_and_validate_deposit_response(deposit_details)
            if not normalized_response:
                security_metrics.record_api_failure(phone_number, "invalid_deposit_response")
                raise DepositError("Invalid deposit data received.", status_code=500)
            
            normalized_response['customer_id'] = customer_id
            
            metadata = {
                'phone_hash': hashlib.sha256(phone_number.encode()).hexdigest()[:8],
                'customer_id_hash': hashlib.sha256(customer_id.encode()).hexdigest()[:8],
                'fetched_at': datetime.now().isoformat(),
                'source': 'deposit_api',
                'status': 'success',
                'deposit_count': len(normalized_response.get('deposits', [])) if isinstance(normalized_response.get('deposits'), list) else 0,
                'security_validated': True
            }
            
            await self.cache.store_in_cache(
                cache_key=cache_key,
                data=normalized_response,
                ttl=self.deposit_cache_ttl,
                metadata=metadata
            )
            
            logger.info(f"Deposit details securely cached for phone: {masked_phone}")
            return normalized_response
            
        except DepositError:
            raise
        except Exception as e:
            security_metrics.record_api_failure(phone_number, "unexpected_deposit")
            logger.error(f"Unexpected error in secure deposit fetch for phone {masked_phone}: {e}", exc_info=True)
            raise DepositError("An unexpected error occurred while fetching deposit information.", status_code=500)

    def _extract_customer_id_from_response(self, response_data: Dict[str, Any], phone_number: str) -> Optional[str]:
        """
        Extract customer ID from API response with enhanced validation
        """
        customer_id = None
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        
        try:
            if 'customers' in response_data:
                customers = response_data['customers']
                if isinstance(customers, list) and customers:
                    for customer in customers:
                        if isinstance(customer, dict) and customer.get('phoneNumber') == phone_number:
                            customer_id = customer.get('customerId')
                            if customer_id and isinstance(customer_id, str):
                                logger.info(f"Customer ID found with phone validation for: {masked_phone}")
                                break
                    if not customer_id and customers:
                        first_customer = customers[0]
                        if isinstance(first_customer, dict):
                            customer_id = first_customer.get('customerId')
                            if customer_id and isinstance(customer_id, str):
                                logger.info(f"Using validated first customer ID for: {masked_phone}")
            
            if not customer_id and 'Data' in response_data:
                data_section = response_data['Data']
                if isinstance(data_section, dict) and 'customers' in data_section:
                    customers = data_section['customers']
                    if isinstance(customers, list) and customers:
                        for customer in customers:
                            if isinstance(customer, dict) and customer.get('phoneNumber') == phone_number:
                                customer_id = customer.get('customerId')
                                if customer_id and isinstance(customer_id, str):
                                    logger.info(f"Customer ID found in Data.customers for: {masked_phone}")
                                    break
                        if not customer_id and customers:
                            first_customer = customers[0]
                            if isinstance(first_customer, dict):
                                customer_id = first_customer.get('customerId')
                                if customer_id and isinstance(customer_id, str):
                                    logger.info(f"Using validated first customer ID from Data.customers")
            
            if not customer_id:
                customer_id = response_data.get('customer_id') or response_data.get('customerId')
                if customer_id and isinstance(customer_id, str):
                    logger.info(f"Customer ID found from direct field")
            
            if not customer_id and 'customerDetails' in response_data:
                customer_details = response_data['customerDetails']
                if isinstance(customer_details, dict):
                    customer_id = customer_details.get('customerId')
                    if customer_id and isinstance(customer_id, str):
                        logger.info(f"Customer ID found from customerDetails")
            
            if customer_id and len(customer_id.strip()) < 3:
                logger.warning(f"Invalid customer ID format detected")
                customer_id = None
        
        except Exception as e:
            logger.error(f"Error extracting customer ID with security validation: {e}", exc_info=True)
        
        return customer_id
    
    def _normalize_and_validate_deposit_response(self, deposit_details: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Normalize and validate the deposit response format with security checks
        """
        try:
            if not isinstance(deposit_details, dict):
                logger.warning(f"Invalid deposit details format: expected dict, got {type(deposit_details)}")
                return None
            
            status = deposit_details.get('status', 'Unknown')
            
            deposits = []
            if 'deposits' in deposit_details:
                deposits = deposit_details['deposits']
            elif 'depositDetails' in deposit_details:
                deposits = deposit_details['depositDetails']
            elif 'Data' in deposit_details and isinstance(deposit_details['Data'], dict):
                deposits = deposit_details['Data'].get('deposit', [])
            
            if not isinstance(deposits, list):
                deposits = []
            
            validated_deposits = []
            for deposit in deposits:
                if self._validate_deposit_record(deposit):
                    validated_deposits.append(deposit)
                else:
                    logger.warning("Invalid deposit record detected and filtered")
            
            return {
                "deposits": validated_deposits,
                "status": status,
                "total_deposits": len(validated_deposits),
                "security_validated": True
            }
            
        except Exception as e:
            logger.error(f"Error normalizing deposit response with security validation: {e}")
            return None

    def _validate_deposit_record(self, deposit_record: Dict[str, Any]) -> bool:
        """Validate individual deposit record integrity"""
        try:
            if not isinstance(deposit_record, dict):
                return False
            
            required_fields = ['customerid', 'depositId', 'depositamount']
            for field in required_fields:
                if field not in deposit_record:
                    return False
            
            deposit_amount = deposit_record.get('depositamount')
            if not isinstance(deposit_amount, (int, float)) or deposit_amount < 0:
                return False
            
            customer_id = deposit_record.get('customerid')
            if not isinstance(customer_id, str) or len(customer_id.strip()) < 3:
                return False
            
            deposit_id = deposit_record.get('depositId')
            if not isinstance(deposit_id, str) or len(deposit_id.strip()) < 3:
                return False
            
            return True
            
        except Exception:
            return False

    def _validate_cached_deposit_data(self, cached_data: Dict[str, Any]) -> bool:
        """Validate cached deposit data integrity and security"""
        try:
            if not isinstance(cached_data, dict):
                return False
            
            if 'data' not in cached_data or 'metadata' not in cached_data:
                return False
            
            metadata = cached_data['metadata']
            if not metadata.get('security_validated', False):
                return False
            
            data = cached_data['data']
            if not isinstance(data, dict):
                return False
            
            deposits = data.get('deposits', [])
            if isinstance(deposits, list):
                for deposit in deposits:
                    if not self._validate_deposit_record(deposit):
                        return False
            
            return True
            
        except Exception:
            return False

    async def get_cached_deposit_details(self, phone_number: str) -> Optional[Dict[str, Any]]:
        """
        Get cached deposit details with security validation
        """
        cache_key = self.cache.generate_cache_key(phone_number, "deposit_details")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            if self._validate_cached_deposit_data(cached_data):
                masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
                logger.info(f"Valid cached deposit details found for phone: {masked_phone}")
                return cached_data['data']
            else:
                await self.clear_deposit_cache(phone_number)
                logger.warning(f"Invalid cached deposit data removed for security")
                return None
        else:
            return None

    async def clear_deposit_cache(self, phone_number: str) -> Dict[str, Any]:
        """
        Securely clears the cached deposit data for a specific phone number.
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Securely clearing deposit cache for phone: {masked_phone}")
        
        cache_key = self.cache.generate_cache_key(phone_number, "deposit_details")
        
        try:
            await self.cache.redis_cache.delete_from_cache(cache_key)
            logger.info(f"Deposit cache securely cleared for phone: {masked_phone}")
            return {
                'success': True,
                'message': 'Deposit cache cleared successfully',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error securely clearing deposit cache for phone {masked_phone}: {e}", exc_info=True)
            return {
                'success': False,
                'error': 'Cache operation failed',
                'timestamp': datetime.now().isoformat()
            }

    async def get_deposit_cache_info(self, phone_number: str) -> Dict[str, Any]:
        """
        Gets deposit cache information with security considerations.
        """
        cache_key = self.cache.generate_cache_key(phone_number, "deposit_details")
        cached_data = await self.cache.get_from_cache(cache_key)
        
        if cached_data:
            metadata = cached_data.get('metadata', {})
            return {
                'cached': True,
                'cached_at': metadata.get('cached_at'),
                'ttl': metadata.get('ttl'),
                'data_available': 'data' in cached_data and cached_data['data'] is not None,
                'security_validated': metadata.get('security_validated', False),
                'source': metadata.get('source', 'unknown')
            }
        else:
            return {
                'cached': False,
                'message': 'No cached data found'
            }

    async def refresh_deposit_details(self, phone_number: str, jwt_token: str = None, customer_id: str = None) -> Optional[Dict[str, Any]]:
        """
        Forces a refresh of deposit details with enhanced security validation
        """
        masked_phone = phone_number[:4] + "****" if len(phone_number) > 4 else "****"
        logger.info(f"Force refreshing deposit details with security validation for phone: {masked_phone}")
        
        if security_metrics.is_suspicious_activity(phone_number):
            raise DepositError("Access temporarily restricted due to security concerns.", status_code=403)
        
        await self.clear_deposit_cache(phone_number)
        
        return await self.get_deposit_details_by_phone(phone_number, jwt_token, customer_id)


redis_cache_instance = RedisCache()
api_redis_cache = APIRedisCache(redis_cache_instance)
user_profile_manager = UserProfileManager(api_redis_cache=api_redis_cache)  
deposit_manager = DepositManager(api_redis_cache=api_redis_cache)

