import json
import logging
from typing import Any, Dict, Optional
import requests
import hashlib
from utils.TokenGeneration import TokenManagement
from utils.resource_manager import resource_manager
token_generator = TokenManagement()

GLOBAL_CUSTOMER_ID = None
GLOBAL_BRANCH_ID = None

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

#################################################################################################################################################################

def generate_hash(data):
    """
    Generates an MD5 hash from a JSON object.
    This function is a common utility for all classes that need it.
    """
    json_string = json.dumps(data, separators=(',', ':'), ensure_ascii=False)
    md5_hash = hashlib.md5()
    md5_hash.update(json_string.encode('utf-8'))
    logger.debug(f"Hash input JSON: {json_string}")
    hash_value = md5_hash.hexdigest().upper()
    return hash_value

def set_global_customer_id(customer_id: str):
    """
    Sets the global customer ID
    """
    global GLOBAL_CUSTOMER_ID
    GLOBAL_CUSTOMER_ID = customer_id
    logger.info(f"Global customer ID set to: {customer_id}")

def get_global_customer_id() -> Optional[str]:
    """
    Gets the global customer ID
    """
    return GLOBAL_CUSTOMER_ID

def set_global_branch_id(branch_id: str):
    """
    Sets the global branch ID
    """
    global GLOBAL_BRANCH_ID
    GLOBAL_BRANCH_ID = branch_id
    logger.info(f"Global branch ID set to: {branch_id}")

def get_global_branch_id() -> Optional[str]:
    """
    Gets the global branch ID
    """
    return GLOBAL_BRANCH_ID

##################################################################################################################################################

class SplashHashing:
    verified_jwt_token = ""
    token_generator = TokenManagement() 

    async def send_request(self, url, splash_data, phone_number: str) -> bool:
        jwt_token = self.token_generator.token_creation()
        if jwt_token is None:
            logger.error("Failed to generate JWT token. Cannot send request.")
            return False
        
        data1 = {"Applicationnumber": "1234", "DeviceID": phone_number, "Jwt": None}
        hash_value = generate_hash(data1)
        nested_data = {"Data": splash_data}
        logger.debug(f"Nested data: {nested_data}")

        request_json = {
            "Type": "SplashRequest",
            "Ver": 1,
            "Hash": hash_value,
            "Data": nested_data
        }

        formatted_request_json = json.dumps(request_json, separators=(',', ':'))
        logger.debug(f"Request JSON: {formatted_request_json}")
        return await self.Send_Api_url(formatted_request_json, url, phone_number)
  
    async def Send_Api_url(self, request_json: Dict[str, Any], url: str, phone_number: str) -> bool:
        from utils.circuit_breaker import api_circuit_breaker
        
        async def _make_request():
            async with resource_manager.managed_session() as session:
                params = {'RequestJson': request_json}
                response = await resource_manager.execute_with_timeout(
                    session.post, url, params=params, timeout=20  # Reduced timeout
                )
                response.raise_for_status()
                return response.json()
        
        try:
            response_data = await api_circuit_breaker.call(_make_request)
        except Exception as e:
            logger.error(f"API call failed: {e}")
            return False

        hash_value = response_data.get('hash', None)
        token = response_data.get('jwtToken', None)
        data_res = response_data.get('data', None)

        request_data = {"Data": data_res, "JWTToken": token, "DeviceToken": phone_number}
        logger.debug(f"Response verification data: {request_data}")
        
        generatedreshash = generate_hash(request_data)        
        if generatedreshash == hash_value:
            self.verified_jwt_token = token
            logger.info(f"Hash match verified. JWT token stored for DeviceToken: {phone_number}.")
            return True
        else:
            logger.warning(f"Hash value mismatch! Received: {hash_value}, Generated: {generatedreshash}")
            return False

##########################################################################################################################################################

class CustomerserviceHash:
    verified_jwt_token = ""
    token_generator = TokenManagement()
    last_call_successful = False

    async def send_request(self, url: str, customer_data: Dict[str, Any], phone_number: str, jwt_token: str) -> Optional[Dict[str, Any]]:
        """
        Modified to accept a SplashHashing instance that already has the verified JWT token
        """
        if not jwt_token:
            logger.error("No JWT token provided. Cannot send request.")
            self.last_call_successful = False
            return None
        
        data_customer = {"phonenumber": phone_number, "DeviceID": phone_number, "Jwt": jwt_token}
        hash_value = generate_hash(data_customer)
        nested_data = {"Data": customer_data}
        logger.debug(f"Nested data: {nested_data}")

        request_json_cust = {
            "Type": "FetchCustomerDetails",
            "Ver": 1,
            "Hash": hash_value,
            "JwtToken": jwt_token,
            "Data": nested_data,
        }

        formatted_request_json = json.dumps(request_json_cust, separators=(',', ':'))
        logger.debug(f"Request JSON: {formatted_request_json}")
        return await self.Send_Api_url(request_json_cust, url, phone_number, jwt_token)

    async def Send_Api_url(self, request_json_cust: Dict[str, Any], url: str, phone_number: str, jwt_token: str) -> Optional[Dict[str, Any]]:
        try:
            async with resource_manager.managed_session() as session:
                headers = {
                    "Authorization": f"Bearer {jwt_token}"
                }
                formatted_json_string = json.dumps(request_json_cust, separators=(',', ':'))
                params = {'RequestJson': formatted_json_string}
                
                response = await resource_manager.execute_with_timeout(
                    session.get, url, params=params, headers=headers, timeout=30
                )
                response.raise_for_status()
                response_data = response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Request to {url} failed: {e}")
            self.last_call_successful = False
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from API response: {e}")
            self.last_call_successful = False
            return None
        except Exception as e:
            logger.error(f"Unexpected error in customer API call: {e}")
            self.last_call_successful = False
            return None

        hash_value = response_data.get('hash', None)
        token = response_data.get('jwtToken', None)
        data_res = response_data.get('data', None)

        request_data = {"Data": data_res, "JWTToken": token, "DeviceToken": phone_number}
        logger.debug(f"Response verification data: {request_data}")

        generatedreshash = generate_hash(request_data)        
        if generatedreshash == hash_value:
            self.verified_jwt_token = token
            logger.info(f"Hash match verified. JWT token stored for DeviceToken: {phone_number}.")
            self.last_call_successful = True
            
            # Extract and store customer ID globally
            if data_res and isinstance(data_res, dict):
                customer_id = data_res.get('customerId') or data_res.get('customerid') or data_res.get('CustomerId')
                if customer_id:
                    set_global_customer_id(customer_id)
                else:
                    logger.warning("Customer ID not found in response data")
            
            return data_res
        else:
            logger.warning(f"Hash value mismatch! Received: {hash_value}, Generated: {generatedreshash}")
            self.last_call_successful = False
            return None

##########################################################################################################################################################

class DepositHash:

    verified_jwt_token = ""
    token_generator = TokenManagement()
    last_call_successful = False

    async def send_request(self, url: str, phone_number: str, jwt_token: str, custom_customer_id: str = None) -> Optional[Dict[str, Any]]:
        """
        Sends deposit details request using the global customer ID or a custom one
        """
        if not jwt_token:
            logger.error("No JWT token provided. Cannot send request.")
            self.last_call_successful = False
            return None
        
        customer_id = custom_customer_id or get_global_customer_id()
        if not customer_id:
            logger.error("No customer ID available. Please fetch customer details first or provide a custom customer ID.")
            self.last_call_successful = False
            return None

        data_deposit = {"customerId": customer_id, "DeviceID": phone_number, "Jwt": jwt_token}
        hash_value = generate_hash(data_deposit)
        
        nested_data = {"Data": {"customerId": customer_id}}
        logger.debug(f"Nested data: {nested_data}")

        request_json_deposit = {
            "Type": "DepositDetailsRequest",
            "Ver": 1,
            "Hash": hash_value,
            "JwtToken": jwt_token,
            "Data": nested_data,
        }

        formatted_request_json = json.dumps(request_json_deposit, separators=(',', ':'))
        logger.debug(f"Request JSON: {formatted_request_json}")
        return await self.Send_Api_url(request_json_deposit, url, phone_number, jwt_token)

    async def Send_Api_url(self, request_json_deposit: Dict[str, Any], url: str, phone_number: str, jwt_token: str) -> Optional[Dict[str, Any]]:
        try:
            async with resource_manager.managed_session() as session:
                headers = {
                    "Authorization": f"Bearer {jwt_token}"
                }
                formatted_json_string = json.dumps(request_json_deposit, separators=(',', ':'))
                params = {'RequestJson': formatted_json_string}
                
                response = await resource_manager.execute_with_timeout(
                    session.get, url, params=params, headers=headers, timeout=30
                )
                response.raise_for_status()
                response_data = response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Request to {url} failed: {e}")
            self.last_call_successful = False
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from API response: {e}")
            self.last_call_successful = False
            return None
        except Exception as e:
            logger.error(f"Unexpected error in deposit API call: {e}")
            self.last_call_successful = False
            return None

        hash_value = response_data.get('hash', None)
        token = response_data.get('jwtToken', None)
        data_res = response_data.get('data', None)
        
        logger.info(f"Deposit API Response - Hash: {hash_value}, Token: {token is not None}, Data: {data_res is not None}")
        
        if data_res is not None and token:
            self.verified_jwt_token = token
            self.last_call_successful = True
            
            if isinstance(data_res, list):
                formatted_response = {
                    "status": "Success",
                    "deposits": data_res
                }
            else:
                formatted_response = data_res
                
            logger.info(f"Deposit details received successfully for phone: {phone_number}")
            return formatted_response
        else:
            logger.warning(f"Invalid or empty response from deposit API for phone: {phone_number}")
            self.last_call_successful = False
            return None
