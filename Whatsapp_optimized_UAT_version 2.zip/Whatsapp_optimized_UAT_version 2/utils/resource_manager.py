import asyncio
import logging
import time
import weakref
from contextlib import asynccontextmanager
from typing import Dict, Any, Optional, Set
import psutil
import gc
import threading
from concurrent.futures import ThreadPoolExecutor
import requests
try:
    from config.resource_config import ResourceConfig
except ImportError:
    # Fallback configuration if config file is not available
    class ResourceConfig:
        CPU_WARNING_THRESHOLD = 80
        MEMORY_WARNING_THRESHOLD = 85
        MAX_CONCURRENT_CONNECTIONS = 50
        CONNECTION_TIMEOUT = 30
        MAX_THREAD_WORKERS = 4
        CLEANUP_INTERVAL = 300
        MONITORING_INTERVAL = 60

logger = logging.getLogger(__name__)

class ResourceManager:
    """Manages CPU resources and API connections with automatic cleanup"""
    
    def __init__(self, max_workers: int = None, connection_timeout: int = None):
        self.max_workers = max_workers or ResourceConfig.MAX_THREAD_WORKERS
        self.connection_timeout = connection_timeout or ResourceConfig.CONNECTION_TIMEOUT
        self.active_connections: Set[requests.Session] = set()
        self.thread_pool = ThreadPoolExecutor(max_workers=self.max_workers)
        self.connection_lock = threading.Lock()
        self._cleanup_task = None
        self._monitoring_task = None
        self.config = ResourceConfig()
        
    async def start_monitoring(self):
        """Start resource monitoring and cleanup tasks"""
        try:
            self._cleanup_task = asyncio.create_task(self._periodic_cleanup())
            self._monitoring_task = asyncio.create_task(self._monitor_resources())
            logger.info("Resource monitoring started")
        except Exception as e:
            logger.error(f"Failed to start monitoring tasks: {e}")
            raise
    
    async def stop_monitoring(self):
        """Stop monitoring tasks and cleanup resources"""
        try:
            if self._cleanup_task:
                self._cleanup_task.cancel()
            if self._monitoring_task:
                self._monitoring_task.cancel()
            
            await self._cleanup_all_connections()
            self.thread_pool.shutdown(wait=True)
            logger.info("Resource monitoring stopped")
        except Exception as e:
            logger.error(f"Error during monitoring shutdown: {e}")
    
    @asynccontextmanager
    async def managed_session(self):
        """Context manager for HTTP sessions with automatic cleanup"""
        session = requests.Session()
        session.timeout = self.connection_timeout
        
        with self.connection_lock:
            self.active_connections.add(session)
        
        try:
            yield session
        finally:
            with self.connection_lock:
                self.active_connections.discard(session)
            session.close()
    
    async def execute_with_timeout(self, func, *args, timeout: int = 30, **kwargs):
        """Execute function with timeout and CPU monitoring"""
        # Check CPU before execution
        cpu = psutil.cpu_percent(interval=0.1)
        if cpu > 85:
            logger.warning(f"High CPU {cpu}%, delaying execution")
            await asyncio.sleep(1)
        
        try:
            loop = asyncio.get_event_loop()
            future = loop.run_in_executor(self.thread_pool, func, *args, **kwargs)
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning(f"Function {func.__name__} timed out after {timeout}s")
            raise
        except Exception as e:
            logger.error(f"Error executing {func.__name__}: {e}")
            raise
    
    async def _periodic_cleanup(self):
        """Periodic cleanup of resources"""
        while True:
            try:
                await asyncio.sleep(self.config.CLEANUP_INTERVAL)
                await self._cleanup_resources()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic cleanup: {e}")
    
    async def _monitor_resources(self):
        """Monitor CPU and memory usage"""
        while True:
            try:
                await asyncio.sleep(self.config.MONITORING_INTERVAL)
                cpu_percent = psutil.cpu_percent(interval=1)
                memory_info = psutil.virtual_memory()
                
                if cpu_percent > self.config.CPU_WARNING_THRESHOLD:
                    logger.warning(f"High CPU usage: {cpu_percent}%")
                    if cpu_percent > self.config.CPU_CRITICAL_THRESHOLD:
                        await self._emergency_cleanup()
                
                if memory_info.percent > self.config.MEMORY_WARNING_THRESHOLD:
                    logger.warning(f"High memory usage: {memory_info.percent}%")
                    gc.collect()
                    if memory_info.percent > self.config.MEMORY_CRITICAL_THRESHOLD:
                        await self._emergency_cleanup()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in resource monitoring: {e}")
    
    async def _cleanup_resources(self):
        """Clean up idle resources"""
        # Force garbage collection
        gc.collect()
        
        # Close idle connections
        await self._cleanup_idle_connections()
        
        logger.debug("Resource cleanup completed")
    
    async def _cleanup_idle_connections(self):
        """Close idle HTTP connections"""
        with self.connection_lock:
            idle_connections = []
            for conn in list(self.active_connections):
                try:
                    # Check if connection is still valid
                    if hasattr(conn, '_pool') and conn._pool:
                        idle_connections.append(conn)
                except:
                    idle_connections.append(conn)
            
            for conn in idle_connections:
                try:
                    conn.close()
                    self.active_connections.discard(conn)
                except:
                    pass
    
    async def _cleanup_all_connections(self):
        """Close all active connections"""
        with self.connection_lock:
            for conn in list(self.active_connections):
                try:
                    conn.close()
                except:
                    pass
            self.active_connections.clear()
    
    async def _emergency_cleanup(self):
        """Emergency cleanup when resources are high"""
        logger.info("Performing emergency resource cleanup")
        
        # Close all connections
        await self._cleanup_all_connections()
        
        # Force garbage collection
        gc.collect()
        
        # Clear any cached data if needed
        await self._clear_caches()
    
    async def _clear_caches(self):
        """Clear application caches during emergency cleanup"""
        try:
            # This would integrate with your Redis cache
            from utils.api_to_redis import api_redis_cache
            if api_redis_cache:
                for pattern in self.config.EMERGENCY_CACHE_CLEAR_PATTERNS:
                    await api_redis_cache.clear_cache(pattern)
        except Exception as e:
            logger.error(f"Error clearing caches: {e}")
    
    def get_resource_stats(self) -> Dict[str, Any]:
        """Get current resource usage statistics"""
        try:
            return {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "active_connections": len(self.active_connections),
                "thread_pool_active": len(self.thread_pool._threads) if hasattr(self.thread_pool, '_threads') else 0,
            }
        except Exception as e:
            logger.error(f"Error getting resource stats: {e}")
            return {"error": "Unable to get resource statistics"}

# Global resource manager instance
resource_manager = ResourceManager()