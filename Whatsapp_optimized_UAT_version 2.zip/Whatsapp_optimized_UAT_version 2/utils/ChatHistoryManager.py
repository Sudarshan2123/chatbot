import json
import logging
from typing import Dict, Any, List
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from utils.redis_cache import RedisCache 
from src.config import MAX_HISTORY_LENGTH

logger = logging.getLogger(__name__)

class ChatHistoryManager:
    """
    Manages loading, saving, and clearing chat history from Redis.
    """
    __slots__ = (
        'redis_client',
        'default_ttl_seconds',
        'MAX_HISTORY_LENGTH',
        'MAX_MESSAGE_LENGTH'
    )
    def __init__(self, redis_client_instance: RedisCache, default_ttl_seconds: int = 1800): # Default TTL 1 hour
        self.redis_client = redis_client_instance
        self.default_ttl_seconds = default_ttl_seconds
        self.MAX_HISTORY_LENGTH = MAX_HISTORY_LENGTH

        logger.info(f"ChatHistoryManager initialized with RedisCache client. Default TTL: {default_ttl_seconds}s.")

    def _serialize_message(self, message: BaseMessage) -> Dict[str, Any]:
        """Serializes a LangChain BaseMessage to a dictionary."""
        return {
            "type": message.type,
            "content": message.content,
            "additional_kwargs": message.additional_kwargs
        }

    def _deserialize_message(self, message_dict: Dict[str, Any]) -> BaseMessage:
        """Deserializes a dictionary back to a LangChain BaseMessage."""
        if message_dict["type"] == "human":
            return HumanMessage(content=message_dict["content"], additional_kwargs=message_dict.get("additional_kwargs", {}))
        elif message_dict["type"] == "ai":
            return AIMessage(content=message_dict["content"], additional_kwargs=message_dict.get("additional_kwargs", {}))
        else:
            raise ValueError(f"Unknown message type: {message_dict['type']}")

    async def load_history(self, session_id: str, limit: int = 10) -> List[BaseMessage]:
        """
        Loads chat history for a session from Redis.
        Extends the TTL of the key on successful load to keep the session alive.
        Limited to prevent memory issues in cluster deployment.
        """
        key = f"chat_history:{session_id}"
        try:
            raw_history = await self.redis_client.get(key)
            if raw_history:
                history_dicts = json.loads(raw_history)
                recent_history = history_dicts[-limit:] if len(history_dicts) > limit else history_dicts
                
                if self.redis_client._redis_client:
                    await self.redis_client._redis_client.expire(key, self.default_ttl_seconds)
                logger.debug(f"Loaded {len(recent_history)} messages for session {session_id}.")
                return [self._deserialize_message(msg_dict) for msg_dict in recent_history]
            logger.debug(f"No chat history found for session {session_id}.")
            return []
        except Exception as e:
            logger.error(f"Error loading chat history for session {session_id}: {e}", exc_info=True)
            return []

    async def add_message_to_history(self, session_id: str, messages: List[BaseMessage]) -> None:
        """
        Adds messages to the chat history for a session in Redis.
        Automatically trims history to MAX_HISTORY_LENGTH to prevent memory bloat.
        The entire history is overwritten with the updated list to ensure consistency.
        """
        key = f"chat_history:{session_id}"
        try:
            current_history = await self.load_history(session_id, limit=MAX_HISTORY_LENGTH)
            
            current_history.extend(messages)
            
            if len(current_history) > MAX_HISTORY_LENGTH:
                current_history = current_history[-MAX_HISTORY_LENGTH:]
                logger.debug(
                    f"Trimmed history for session {session_id} to {MAX_HISTORY_LENGTH} messages "
                    f"(removed {len(current_history) - MAX_HISTORY_LENGTH} oldest messages)"
                )
            
            serialized_history = [self._serialize_message(msg) for msg in current_history]
            
            await self.redis_client.set_to_cache(
                key, 
                json.dumps(serialized_history), 
                expiration_seconds=self.default_ttl_seconds
            )
            
            logger.debug(
                f"Added {len(messages)} messages to chat history for session {session_id}. "
                f"Total history: {len(serialized_history)} messages. Saved to Redis with TTL: {self.default_ttl_seconds}s."
            )
            
        except Exception as e:
            logger.error(f"Error adding messages to history for session {session_id}: {e}", exc_info=True)

    async def clear_history(self, session_id: str) -> None:
        """Clears chat history for a session from Redis."""
        key = f"chat_history:{session_id}"
        try:
            await self.redis_client.delete_from_cache(key)
            logger.info(f"Cleared chat history for session {session_id} from Redis.")
        except Exception as e:
            logger.error(f"Error clearing chat history for session {session_id}: {e}", exc_info=True)

    

    

