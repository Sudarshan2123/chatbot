import asyncio
import psutil
import logging
import time

logger = logging.getLogger(__name__)

class StartupThrottle:
    """Throttles initialization to prevent CPU spikes"""
    
    def __init__(self, max_cpu=70, check_interval=0.5):
        self.max_cpu = max_cpu
        self.check_interval = check_interval
    
    async def wait_for_cpu(self):
        """Wait until CPU usage is below threshold"""
        while True:
            cpu = psutil.cpu_percent(interval=0.1)
            if cpu < self.max_cpu:
                break
            logger.warning(f"CPU at {cpu}%, waiting...")
            await asyncio.sleep(self.check_interval)
    
    async def throttled_init(self, init_func, name="service"):
        """Initialize service with CPU throttling"""
        await self.wait_for_cpu()
        logger.info(f"Starting {name} initialization")
        
        try:
            result = await init_func()
            await asyncio.sleep(0.1)  # Brief pause between inits
            return result
        except Exception as e:
            logger.error(f"{name} initialization failed: {e}")
            raise

throttle = StartupThrottle()