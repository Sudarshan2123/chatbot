import logging
from typing import Any, Dict, Optional
import jwt
from datetime import datetime, timedelta, timezone
from src.config import SECRET_KEY,ALGORITHM


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TokenManagement:
    """
    Enhanced TokenManagement class for creating and validating JWT tokens.

    """
    __slots__ = ('secret_key', 'algorithm')
    def __init__(self):
        self.secret_key = SECRET_KEY
        self.algorithm = ALGORITHM
        

    def token_creation(self):
        payload = {
        "user_id": "7306879412",
        "exp": datetime.now(timezone.utc) + timedelta(minutes=30)  }  
        encoded_jwt = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
        return encoded_jwt
    
           
    def validate_token(self, token: str) -> Optional[Dict[str, Any]]:
        try:
            decoded_payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            print("SUCCESS! Token decoded successfully.")
            logger.info(f"Token validated successfully for user_id: {decoded_payload.get('user_id')}")
            return decoded_payload
        except jwt.ExpiredSignatureError:
            logger.error("Token has expired.")
            return None
        except jwt.InvalidTokenError as e:
            logger.error(f"Invalid token: {e}")
            return None
        except Exception as e:
            logger.error(f"Error validating token: {e}", exc_info=True)
            return None
        

    def extract_phone_from_token(self, token: str) -> Optional[str]:
        payload = self.validate_token(token)
        if payload:
            return payload.get("user_id")
        return None
    

    def get_token_expiry(self, token: str) -> Optional[datetime]:
        """
        Get the expiry time of a token.
        """
        payload = self.validate_token(token)
        if payload and 'exp' in payload:
            return datetime.fromtimestamp(payload['exp'], tz=timezone.utc)
        return None
    
    
token_manager = TokenManagement()




import jwt
from datetime import datetime, timezone
import base64


class CSRFTokenVerification:
    def __init__(self):
        self.secret_key = SECRET_KEY
        self.algorithm = ALGORITHM
    
    def get_principal(self, token):
        """
        Decode and validate JWT token structure
        
        Args:
            token (str): JWT token string
            
        Returns:
            dict: Decoded token payload or None if invalid
        """
        try:
            # Decode without verification first to check structure
            decoded = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                options={
                    'verify_signature': True,
                    'verify_exp': True,
                    'require_exp': True
                }
            )
            return decoded
        except Exception:
            return None
    
    @staticmethod
    def unix_time_to_datetime(unix_time):
        """
        Convert Unix timestamp to datetime object
        
        Args:
            unix_time (int): Unix timestamp
            
        Returns:
            datetime: Converted datetime object in local time
        """
        dt_utc = datetime.fromtimestamp(unix_time, tz=timezone.utc)
        return dt_utc.astimezone()
    
    def validate_token(self, token):
        """
        Validate JWT token and extract username
        
        Args:
            token (str): JWT token string
            
        Returns:
            str: Username from token or None if invalid/expired
        """
        try:
            principal = self.get_principal(token)
            
            if principal is None:
                return None
            
            exp = principal.get('exp')
            if exp is None:
                return None
            
            token_expiry_time = datetime.fromtimestamp(exp, tz=timezone.utc)
            
            if token_expiry_time < datetime.now(timezone.utc):
                return None
            
            user_id = principal.get('user_id') or principal.get('name') or principal.get('sub') or principal.get('unique_name')
            
            if not user_id:
                logger.warning(f"Token validation failed: no user identifier found in claims. Available claims: {list(principal.keys())}")
                return None
            
            logger.info(f"CSRF token validated successfully for user_id: {user_id[:4]}****")
            return user_id
            
        except Exception as e:
            logger.error(f"Error validating CSRF token: {e}", exc_info=True)
            return None


csrf_verifier = CSRFTokenVerification()