import os
import base64
import logging
from typing import Optional, Dict, Any

from src.config import AES_ENCRYPTION_KEY

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.backends import default_backend

logger = logging.getLogger(__name__)

_AES_KEY: Optional[bytes] = None
_ENCRYPTION_KEY_B64 = AES_ENCRYPTION_KEY

if _ENCRYPTION_KEY_B64:
    try:
        _AES_KEY = base64.urlsafe_b64decode(_ENCRYPTION_KEY_B64)
        if len(_AES_KEY) != 32:
            logger.critical(f"AES-256 key must be 32 bytes (256 bits) long. Got {len(_AES_KEY)} bytes. Please check your ENCRYPTION_KEY.")
            raise ValueError("Incorrect encryption key length.")
        logger.info("AES-256 encryption key loaded successfully from config.")
    except Exception as e:
        logger.critical(f"Error loading or validating encryption key from config: {e}", exc_info=True)
        _AES_KEY = None 
else:
    logger.warning("ENCRYPTION_KEY not found in config or environment variables. Encryption/Decryption will be disabled.")


_aesgcm: Optional[AESGCM] = None
if _AES_KEY:
    try:
        _aesgcm = AESGCM(_AES_KEY)
        logger.info("AESGCM encryptor initialized.")
    except Exception as e:
        logger.critical(f"Error initializing AESGCM with provided key: {e}", exc_info=True)
        _aesgcm = None

def encrypt_data(plain_text: str) -> Optional[Dict[str, str]]:
    """
    Encrypts a string using AES-256-GCM.
    Generates a new 12-byte nonce (IV) for each encryption.
    Returns a dictionary with base64-encoded encrypted data, nonce (IV), and authentication tag.
    Returns None if encryption is disabled or an error occurs.
    """
    if not _aesgcm:
        logger.warning("Encryption is disabled (AES-256 key or AESGCM not initialized). Returning None.")
        return None 

    try:
        nonce = os.urandom(12) 
        aad = b"" 
        encrypted_data_with_tag = _aesgcm.encrypt(nonce, plain_text.encode('utf-8'), aad)
        
        tag_length = 16 
        ciphertext_bytes = encrypted_data_with_tag[:-tag_length]
        tag_bytes = encrypted_data_with_tag[-tag_length:]
        
        return {
            "encrypted_data": base64.urlsafe_b64encode(ciphertext_bytes).decode('utf-8'),
            "iv": base64.urlsafe_b64encode(nonce).decode('utf-8'),
            "tag": base64.urlsafe_b64encode(tag_bytes).decode('utf-8')
        }
    except Exception as e:
        logger.error(f"Error encrypting data: {e}", exc_info=True)
        return None

