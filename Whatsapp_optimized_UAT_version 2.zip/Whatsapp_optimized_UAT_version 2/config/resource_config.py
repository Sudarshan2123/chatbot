"""
Resource Management Configuration
"""
import os
from typing import Dict, Any

class ResourceConfig:
    """Configuration settings for resource management"""
    
    # CPU and Memory thresholds
    CPU_WARNING_THRESHOLD = int(os.getenv('CPU_WARNING_THRESHOLD', '80'))
    CPU_CRITICAL_THRESHOLD = int(os.getenv('CPU_CRITICAL_THRESHOLD', '90'))
    MEMORY_WARNING_THRESHOLD = int(os.getenv('MEMORY_WARNING_THRESHOLD', '85'))
    MEMORY_CRITICAL_THRESHOLD = int(os.getenv('MEMORY_CRITICAL_THRESHOLD', '95'))
    
    # Connection management
    MAX_CONCURRENT_CONNECTIONS = int(os.getenv('MAX_CONCURRENT_CONNECTIONS', '50'))
    CONNECTION_TIMEOUT = int(os.getenv('CONNECTION_TIMEOUT', '30'))
    MAX_THREAD_WORKERS = int(os.getenv('MAX_THREAD_WORKERS', '4'))
    
    # Cleanup intervals (in seconds)
    CLEANUP_INTERVAL = int(os.getenv('CLEANUP_INTERVAL', '300'))  # 5 minutes
    MONITORING_INTERVAL = int(os.getenv('MONITORING_INTERVAL', '60'))  # 1 minute
    
    # Cache settings
    EMERGENCY_CACHE_CLEAR_PATTERNS = [
        'temp_*',
        'session_*',
        'api_cache:*'
    ]
    
    # API timeout settings
    API_REQUEST_TIMEOUT = int(os.getenv('API_REQUEST_TIMEOUT', '30'))
    API_RETRY_ATTEMPTS = int(os.getenv('API_RETRY_ATTEMPTS', '3'))
    
    @classmethod
    def get_config(cls) -> Dict[str, Any]:
        """Get all configuration as dictionary"""
        return {
            'cpu_warning_threshold': cls.CPU_WARNING_THRESHOLD,
            'cpu_critical_threshold': cls.CPU_CRITICAL_THRESHOLD,
            'memory_warning_threshold': cls.MEMORY_WARNING_THRESHOLD,
            'memory_critical_threshold': cls.MEMORY_CRITICAL_THRESHOLD,
            'max_concurrent_connections': cls.MAX_CONCURRENT_CONNECTIONS,
            'connection_timeout': cls.CONNECTION_TIMEOUT,
            'max_thread_workers': cls.MAX_THREAD_WORKERS,
            'cleanup_interval': cls.CLEANUP_INTERVAL,
            'monitoring_interval': cls.MONITORING_INTERVAL,
            'api_request_timeout': cls.API_REQUEST_TIMEOUT,
            'api_retry_attempts': cls.API_RETRY_ATTEMPTS
        }
    
    @classmethod
    def validate_config(cls) -> bool:
        """Validate configuration values"""
        try:
            assert 0 < cls.CPU_WARNING_THRESHOLD < 100
            assert 0 < cls.CPU_CRITICAL_THRESHOLD < 100
            assert cls.CPU_WARNING_THRESHOLD < cls.CPU_CRITICAL_THRESHOLD
            
            assert 0 < cls.MEMORY_WARNING_THRESHOLD < 100
            assert 0 < cls.MEMORY_CRITICAL_THRESHOLD < 100
            assert cls.MEMORY_WARNING_THRESHOLD < cls.MEMORY_CRITICAL_THRESHOLD
            
            assert cls.MAX_CONCURRENT_CONNECTIONS > 0
            assert cls.CONNECTION_TIMEOUT > 0
            assert cls.MAX_THREAD_WORKERS > 0
            
            return True
        except AssertionError:
            return False